import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';
import { checkDatabaseConnection } from './db.js';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.use(express.json());

// Data Interfaces
export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  price: number;
  quantity: number;
  unit: string;
  supplierId: string;
  supplierName: string;
  locationId: string;
  locationCode: string;
  lowStockThreshold: number;
  description: string;
  lastUpdated: string;
}

export interface Supplier {
  id: string;
  name: string;
  code: string;
  contactPerson: string;
  email: string;
  phone: string;
  leadTimeDays: number;
  rating: number;
  status: 'ACTIVE' | 'INACTIVE';
}

export interface WarehouseLocation {
  id: string;
  code: string;
  zone: string;
  aisle: string;
  rack: string;
  shelf: string;
  type: 'PALLET_RACK' | 'HIGH_BAY' | 'COLD_STORAGE' | 'BIN_SHELVING' | 'DOCK_BAY';
  maxCapacity: number;
  currentOccupancy: number;
  status: 'AVAILABLE' | 'FULL' | 'MAINTENANCE';
}

export interface StockMovement {
  id: string;
  productId: string;
  productName: string;
  sku: string;
  type: 'INBOUND' | 'INTERNAL_TRANSFER' | 'OUTBOUND' | 'ADJUSTMENT';
  quantity: number;
  fromLocation?: string;
  toLocation?: string;
  referenceNumber: string;
  reason?: string;
  timestamp: string;
  operator: string;
}

export interface PurchaseOrder {
  id: string;
  orderNumber: string;
  supplierId: string;
  supplierName: string;
  status: 'DRAFT' | 'PENDING' | 'IN_TRANSIT' | 'RECEIVED' | 'CANCELLED';
  items: {
    productId: string;
    productName: string;
    sku: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
  }[];
  totalAmount: number;
  orderDate: string;
  expectedDeliveryDate: string;
  receivedDate?: string;
  destinationLocationId: string;
  destinationLocationCode: string;
  notes?: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: 'Warehouse Manager' | 'Inventory Specialist' | 'Logistics Staff';
  passwordHash: string;
  avatarUrl: string;
}

// Simple Everyday Categories
let categories: string[] = [
  'Electronics',
  'Clothing & Apparel',
  'Kitchen & Home',
  'Office Supplies',
  'Food & Beverages'
];

// Simple Recognized Suppliers
let suppliers: Supplier[] = [
  {
    id: 'SUP-001',
    name: 'Global Electronics Co',
    code: 'GEC',
    contactPerson: 'David Miller',
    email: 'orders@globalelectronics.com',
    phone: '+1 (555) 234-5678',
    leadTimeDays: 5,
    rating: 4.8,
    status: 'ACTIVE'
  },
  {
    id: 'SUP-002',
    name: 'Prime Apparel Works',
    code: 'PAW',
    contactPerson: 'Sarah Jenkins',
    email: 'supply@primeapparel.com',
    phone: '+1 (555) 789-0123',
    leadTimeDays: 7,
    rating: 4.9,
    status: 'ACTIVE'
  },
  {
    id: 'SUP-003',
    name: 'Urban Home Goods',
    code: 'UHG',
    contactPerson: 'Michael Chang',
    email: 'sales@urbanhomegoods.com',
    phone: '+1 (555) 456-7890',
    leadTimeDays: 4,
    rating: 4.7,
    status: 'ACTIVE'
  },
  {
    id: 'SUP-004',
    name: 'Office Essentials Supply',
    code: 'OES',
    contactPerson: 'Emma Watson',
    email: 'contact@officeessentials.com',
    phone: '+1 (555) 890-1234',
    leadTimeDays: 3,
    rating: 4.6,
    status: 'ACTIVE'
  },
  {
    id: 'SUP-005',
    name: 'Daily Goods Supply',
    code: 'DGS',
    contactPerson: 'Alex Rivera',
    email: 'dispatch@dailygoods.com',
    phone: '+1 (555) 321-6540',
    leadTimeDays: 2,
    rating: 4.8,
    status: 'ACTIVE'
  }
];

// Simple Recognized Locations
let locations: WarehouseLocation[] = [
  {
    id: 'LOC-A01',
    code: 'A-01-A',
    zone: 'Zone A (General Shelves)',
    aisle: 'Aisle 1',
    rack: 'Rack A',
    shelf: 'Shelf 1',
    type: 'PALLET_RACK',
    maxCapacity: 1200,
    currentOccupancy: 415,
    status: 'AVAILABLE'
  },
  {
    id: 'LOC-A02',
    code: 'A-02-B',
    zone: 'Zone A (General Shelves)',
    aisle: 'Aisle 2',
    rack: 'Rack B',
    shelf: 'Shelf 2',
    type: 'PALLET_RACK',
    maxCapacity: 1000,
    currentOccupancy: 24,
    status: 'AVAILABLE'
  },
  {
    id: 'LOC-B01',
    code: 'B-01-A',
    zone: 'Zone B (Electronics Bay)',
    aisle: 'Aisle 1',
    rack: 'Rack A',
    shelf: 'Shelf 1',
    type: 'HIGH_BAY',
    maxCapacity: 500,
    currentOccupancy: 192,
    status: 'AVAILABLE'
  },
  {
    id: 'LOC-B02',
    code: 'B-02-A',
    zone: 'Zone B (Electronics Bay)',
    aisle: 'Aisle 2',
    rack: 'Rack A',
    shelf: 'Shelf 2',
    type: 'HIGH_BAY',
    maxCapacity: 600,
    currentOccupancy: 15,
    status: 'AVAILABLE'
  },
  {
    id: 'LOC-C01',
    code: 'C-01-A',
    zone: 'Zone C (Office & Paper Storage)',
    aisle: 'Aisle 1',
    rack: 'Rack A',
    shelf: 'Shelf 1',
    type: 'BIN_SHELVING',
    maxCapacity: 1500,
    currentOccupancy: 450,
    status: 'AVAILABLE'
  },
  {
    id: 'LOC-D01',
    code: 'D-01-A',
    zone: 'Zone D (Food & Beverage Room)',
    aisle: 'Aisle 1',
    rack: 'Rack A',
    shelf: 'Shelf 1',
    type: 'COLD_STORAGE',
    maxCapacity: 800,
    currentOccupancy: 160,
    status: 'AVAILABLE'
  },
  {
    id: 'LOC-RCV',
    code: 'DOCK-01',
    zone: 'Receiving Dock Bay',
    aisle: 'Dock 1',
    rack: 'Staging',
    shelf: 'Floor',
    type: 'DOCK_BAY',
    maxCapacity: 3000,
    currentOccupancy: 120,
    status: 'AVAILABLE'
  }
];

// SIMPLE EVERYDAY PRODUCTS (Crystal clear, universally understood)
let products: Product[] = [
  {
    id: 'PRD-1001',
    name: 'Wireless Bluetooth Headphones',
    sku: 'HEADPHONE-BT-01',
    category: 'Electronics',
    price: 49.99,
    quantity: 180,
    unit: 'units',
    supplierId: 'SUP-001',
    supplierName: 'Global Electronics Co',
    locationId: 'LOC-B01',
    locationCode: 'B-01-A',
    lowStockThreshold: 30,
    description: 'Over-ear noise-cancelling wireless Bluetooth headphones with 30-hour battery life.',
    lastUpdated: '2026-10-28T09:15:00Z'
  },
  {
    id: 'PRD-1002',
    name: 'Cotton Crewneck T-Shirt (Black)',
    sku: 'TSHIRT-BLK-M',
    category: 'Clothing & Apparel',
    price: 14.50,
    quantity: 24, // Low stock warning!
    unit: 'pcs',
    supplierId: 'SUP-002',
    supplierName: 'Prime Apparel Works',
    locationId: 'LOC-A02',
    locationCode: 'A-02-B',
    lowStockThreshold: 50,
    description: '100% combed organic cotton regular fit unisex crewneck t-shirt.',
    lastUpdated: '2026-10-29T14:22:00Z'
  },
  {
    id: 'PRD-1003',
    name: 'Stainless Steel Water Bottle 750ml',
    sku: 'BOTTLE-STEEL-750',
    category: 'Kitchen & Home',
    price: 18.00,
    quantity: 95,
    unit: 'bottles',
    supplierId: 'SUP-003',
    supplierName: 'Urban Home Goods',
    locationId: 'LOC-A01',
    locationCode: 'A-01-A',
    lowStockThreshold: 25,
    description: 'Vacuum insulated double-wall stainless steel bottle, keeps drinks cold 24h.',
    lastUpdated: '2026-10-27T11:00:00Z'
  },
  {
    id: 'PRD-1004',
    name: 'USB-C Fast Charging Cable (2m)',
    sku: 'CABLE-USBC-2M',
    category: 'Electronics',
    price: 9.99,
    quantity: 15, // Low stock warning!
    unit: 'units',
    supplierId: 'SUP-001',
    supplierName: 'Global Electronics Co',
    locationId: 'LOC-B02',
    locationCode: 'B-02-A',
    lowStockThreshold: 40,
    description: 'Heavy duty nylon braided USB Type-C 100W fast charging and data sync cable.',
    lastUpdated: '2026-10-29T16:45:00Z'
  },
  {
    id: 'PRD-1005',
    name: 'Ceramic Coffee Mug (White)',
    sku: 'MUG-CERAMIC-WHT',
    category: 'Kitchen & Home',
    price: 6.50,
    quantity: 320,
    unit: 'pcs',
    supplierId: 'SUP-003',
    supplierName: 'Urban Home Goods',
    locationId: 'LOC-A01',
    locationCode: 'A-01-A',
    lowStockThreshold: 60,
    description: 'Classic 350ml ceramic coffee and tea mug, dishwasher and microwave safe.',
    lastUpdated: '2026-10-25T08:30:00Z'
  },
  {
    id: 'PRD-1006',
    name: 'Ergonomic Wireless Computer Mouse',
    sku: 'MOUSE-WRL-BLK',
    category: 'Electronics',
    price: 28.00,
    quantity: 12, // Low stock warning!
    unit: 'units',
    supplierId: 'SUP-001',
    supplierName: 'Global Electronics Co',
    locationId: 'LOC-B01',
    locationCode: 'B-01-A',
    lowStockThreshold: 30,
    description: 'Comfortable wireless optical mouse with quiet click buttons and 2.4GHz USB receiver.',
    lastUpdated: '2026-10-29T17:10:00Z'
  },
  {
    id: 'PRD-1007',
    name: 'A4 Copy Paper Ream (500 Sheets)',
    sku: 'PAPER-A4-500',
    category: 'Office Supplies',
    price: 5.25,
    quantity: 450,
    unit: 'reams',
    supplierId: 'SUP-004',
    supplierName: 'Office Essentials Supply',
    locationId: 'LOC-C01',
    locationCode: 'C-01-A',
    lowStockThreshold: 100,
    description: 'Standard 80gsm premium white multi-purpose office copy and printing paper.',
    lastUpdated: '2026-10-26T10:00:00Z'
  },
  {
    id: 'PRD-1008',
    name: 'Gel Ballpoint Pens (Pack of 12)',
    sku: 'PEN-GEL-BLU-12',
    category: 'Office Supplies',
    price: 7.90,
    quantity: 8, // Very low stock!
    unit: 'packs',
    supplierId: 'SUP-004',
    supplierName: 'Office Essentials Supply',
    locationId: 'LOC-C01',
    locationCode: 'C-01-A',
    lowStockThreshold: 40,
    description: 'Smooth writing 0.7mm quick-drying blue ink gel rollerball pens.',
    lastUpdated: '2026-10-30T06:00:00Z'
  },
  {
    id: 'PRD-1009',
    name: 'Organic Green Tea (Pack of 50 Bags)',
    sku: 'TEA-GRN-50BG',
    category: 'Food & Beverages',
    price: 11.20,
    quantity: 160,
    unit: 'boxes',
    supplierId: 'SUP-005',
    supplierName: 'Daily Goods Supply',
    locationId: 'LOC-D01',
    locationCode: 'D-01-A',
    lowStockThreshold: 35,
    description: 'Certified organic whole leaf green tea bags rich in natural antioxidants.',
    lastUpdated: '2026-10-28T12:00:00Z'
  },
  {
    id: 'PRD-1010',
    name: 'Canvas Backpack with Laptop Sleeve',
    sku: 'BAG-CANVAS-GRY',
    category: 'Clothing & Apparel',
    price: 39.00,
    quantity: 5, // Very low stock!
    unit: 'bags',
    supplierId: 'SUP-002',
    supplierName: 'Prime Apparel Works',
    locationId: 'LOC-A01',
    locationCode: 'A-01-A',
    lowStockThreshold: 20,
    description: 'Water resistant durable canvas daypack fitting laptops up to 15.6 inches.',
    lastUpdated: '2026-10-30T07:00:00Z'
  }
];

let stockMovements: StockMovement[] = [
  {
    id: 'MOV-801',
    productId: 'PRD-1001',
    productName: 'Wireless Bluetooth Headphones',
    sku: 'HEADPHONE-BT-01',
    type: 'INBOUND',
    quantity: 100,
    fromLocation: 'Supplier Delivery / Dock 1',
    toLocation: 'B-01-A',
    referenceNumber: 'PO-2026-089',
    reason: 'Purchase order goods receipt into electronics bay',
    timestamp: '2026-10-28T09:15:00Z',
    operator: 'Alex Rivera'
  },
  {
    id: 'MOV-802',
    productId: 'PRD-1002',
    productName: 'Cotton Crewneck T-Shirt (Black)',
    sku: 'TSHIRT-BLK-M',
    type: 'OUTBOUND',
    quantity: 36,
    fromLocation: 'A-02-B',
    toLocation: 'Dispatch Lane 1 / Courier',
    referenceNumber: 'SO-9921',
    reason: 'Customer online order dispatch',
    timestamp: '2026-10-29T14:22:00Z',
    operator: 'Sarah Chen'
  },
  {
    id: 'MOV-803',
    productId: 'PRD-1003',
    productName: 'Stainless Steel Water Bottle 750ml',
    sku: 'BOTTLE-STEEL-750',
    type: 'INTERNAL_TRANSFER',
    quantity: 25,
    fromLocation: 'DOCK-01',
    toLocation: 'A-01-A',
    referenceNumber: 'INT-3301',
    reason: 'Staging to shelf bin transfer',
    timestamp: '2026-10-27T11:00:00Z',
    operator: 'Marcus Vance'
  },
  {
    id: 'MOV-804',
    productId: 'PRD-1004',
    productName: 'USB-C Fast Charging Cable (2m)',
    sku: 'CABLE-USBC-2M',
    type: 'OUTBOUND',
    quantity: 25,
    fromLocation: 'B-02-A',
    toLocation: 'Express Packing Station',
    referenceNumber: 'SO-9934',
    reason: 'Store fulfillment dispatch',
    timestamp: '2026-10-29T17:10:00Z',
    operator: 'Sarah Chen'
  },
  {
    id: 'MOV-805',
    productId: 'PRD-1008',
    productName: 'Gel Ballpoint Pens (Pack of 12)',
    sku: 'PEN-GEL-BLU-12',
    type: 'ADJUSTMENT',
    quantity: -2,
    fromLocation: 'C-01-A',
    toLocation: 'Damaged Goods Bin',
    referenceNumber: 'CYC-104',
    reason: 'Box damaged during shelving write-off',
    timestamp: '2026-10-30T06:00:00Z',
    operator: 'Marcus Vance'
  }
];

let purchaseOrders: PurchaseOrder[] = [
  {
    id: 'PO-2026-089',
    orderNumber: 'PO-2026-089',
    supplierId: 'SUP-001',
    supplierName: 'Global Electronics Co',
    status: 'RECEIVED',
    items: [
      {
        productId: 'PRD-1001',
        productName: 'Wireless Bluetooth Headphones',
        sku: 'HEADPHONE-BT-01',
        quantity: 100,
        unitPrice: 38.00,
        totalPrice: 3800.00
      }
    ],
    totalAmount: 3800.00,
    orderDate: '2026-10-15T10:00:00Z',
    expectedDeliveryDate: '2026-10-27T10:00:00Z',
    receivedDate: '2026-10-28T09:15:00Z',
    destinationLocationId: 'LOC-B01',
    destinationLocationCode: 'B-01-A',
    notes: 'Restock shipment for holiday season'
  },
  {
    id: 'PO-2026-092',
    orderNumber: 'PO-2026-092',
    supplierId: 'SUP-002',
    supplierName: 'Prime Apparel Works',
    status: 'IN_TRANSIT',
    items: [
      {
        productId: 'PRD-1002',
        productName: 'Cotton Crewneck T-Shirt (Black)',
        sku: 'TSHIRT-BLK-M',
        quantity: 80,
        unitPrice: 9.50,
        totalPrice: 760.00
      },
      {
        productId: 'PRD-1010',
        productName: 'Canvas Backpack with Laptop Sleeve',
        sku: 'BAG-CANVAS-GRY',
        quantity: 40,
        unitPrice: 24.00,
        totalPrice: 960.00
      }
    ],
    totalAmount: 1720.00,
    orderDate: '2026-10-24T14:30:00Z',
    expectedDeliveryDate: '2026-10-31T12:00:00Z',
    destinationLocationId: 'LOC-A02',
    destinationLocationCode: 'A-02-B',
    notes: 'Urgent restocking for low inventory'
  },
  {
    id: 'PO-2026-095',
    orderNumber: 'PO-2026-095',
    supplierId: 'SUP-004',
    supplierName: 'Office Essentials Supply',
    status: 'PENDING',
    items: [
      {
        productId: 'PRD-1008',
        productName: 'Gel Ballpoint Pens (Pack of 12)',
        sku: 'PEN-GEL-BLU-12',
        quantity: 120,
        unitPrice: 4.80,
        totalPrice: 576.00
      }
    ],
    totalAmount: 576.00,
    orderDate: '2026-10-29T11:20:00Z',
    expectedDeliveryDate: '2026-11-04T15:00:00Z',
    destinationLocationId: 'LOC-C01',
    destinationLocationCode: 'C-01-A',
    notes: 'Awaiting supplier dispatch'
  }
];

// Accounts & Auth
let users: UserAccount[] = [
  {
    id: 'USR-01',
    name: 'Alex Rivera',
    email: 'manager@warehouse.com',
    role: 'Warehouse Manager',
    passwordHash: 'admin123',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 'USR-02',
    name: 'Sarah Chen',
    email: 'operator@warehouse.com',
    role: 'Inventory Specialist',
    passwordHash: 'pass123',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80'
  }
];

// Helper: Demand Forecast
function generateForecastData(product: Product) {
  const baseBurnRate = Math.max(1.5, (product.price > 30 ? 2.5 : 8.0) * (product.lowStockThreshold / 30));
  const leadTime = suppliers.find(s => s.id === product.supplierId)?.leadTimeDays || 5;
  
  const historicalWeeks = [];
  const weekLabels = ['W-8', 'W-7', 'W-6', 'W-5', 'W-4', 'W-3', 'W-2', 'W-1'];
  let totalHistorical = 0;
  
  for (let i = 0; i < 8; i++) {
    const noise = Math.sin((i + product.id.charCodeAt(product.id.length - 1)) * 0.9) * (baseBurnRate * 0.3);
    const demand = Math.max(1, Math.round(baseBurnRate * 7 + noise));
    historicalWeeks.push({ week: weekLabels[i], demand });
    totalHistorical += demand;
  }

  const avgWeeklyDemand = totalHistorical / 8;
  const avgDailyDemand = Number((avgWeeklyDemand / 7).toFixed(2));
  
  const variance = historicalWeeks.reduce((acc, curr) => acc + Math.pow(curr.demand - avgWeeklyDemand, 2), 0) / 8;
  const stdDevDaily = Math.sqrt(variance / 7);

  const safetyStock = Math.ceil(1.65 * Math.sqrt(leadTime) * stdDevDaily);
  const reorderPoint = Math.ceil((leadTime * avgDailyDemand) + safetyStock);
  const daysRemaining = avgDailyDemand > 0 ? Number((product.quantity / avgDailyDemand).toFixed(1)) : 999;
  
  const annualDemand = avgDailyDemand * 365;
  const eoq = Math.round(Math.sqrt((2 * annualDemand * 35) / Math.max(1, product.price * 0.15)));
  const recommendedRestockQty = Math.max(eoq, Math.ceil(avgDailyDemand * 30));

  const forecastWeeks = [];
  const forecastLabels = ['W+1 (Est)', 'W+2 (Est)', 'W+3 (Est)', 'W+4 (Est)'];
  let projectedTotalNext30Days = 0;

  for (let i = 0; i < 4; i++) {
    const trendFactor = 1 + (0.02 * (i + 1));
    const projectedDemand = Math.round(avgWeeklyDemand * trendFactor);
    forecastWeeks.push({ week: forecastLabels[i], demand: projectedDemand });
    projectedTotalNext30Days += projectedDemand;
  }

  let riskLevel: 'CRITICAL_STOCKOUT' | 'LOW_STOCK_RISK' | 'HEALTHY' | 'SURPLUS' = 'HEALTHY';
  if (product.quantity <= 0) {
    riskLevel = 'CRITICAL_STOCKOUT';
  } else if (daysRemaining <= leadTime) {
    riskLevel = 'CRITICAL_STOCKOUT';
  } else if (daysRemaining <= leadTime * 2 || product.quantity <= product.lowStockThreshold) {
    riskLevel = 'LOW_STOCK_RISK';
  } else if (daysRemaining > 90) {
    riskLevel = 'SURPLUS';
  }

  return {
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    category: product.category,
    currentStock: product.quantity,
    lowStockThreshold: product.lowStockThreshold,
    avgDailyDemand,
    avgWeeklyDemand: Math.round(avgWeeklyDemand),
    leadTimeDays: leadTime,
    safetyStock,
    reorderPoint,
    daysRemaining,
    recommendedRestockQty,
    projected30DayDemand: projectedTotalNext30Days,
    riskLevel,
    historicalWeeks,
    forecastWeeks
  };
}

// ---------------- REST API ROUTES ----------------

// Authentication Routes
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required' });
  }

  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
  if (!user || user.passwordHash !== password) {
    return res.status(401).json({ success: false, message: 'Invalid email or password' });
  }

  const { passwordHash, ...userProfile } = user;
  res.json({ success: true, user: userProfile });
});

app.post('/api/auth/signup', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ success: false, message: 'Name, email, and password are required' });
  }

  const existing = users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
  if (existing) {
    return res.status(400).json({ success: false, message: 'An account with this email already exists' });
  }

  const newUser: UserAccount = {
    id: `USR-${String(users.length + 1).padStart(2, '0')}`,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    role: role || 'Inventory Specialist',
    passwordHash: password,
    avatarUrl: ''
  };

  users.push(newUser);
  const { passwordHash, ...userProfile } = newUser;
  res.status(201).json({ success: true, user: userProfile });
});

// Download ZIP of Project
function addDirectoryToZip(zip: JSZip, folderPath: string, rootDir: string) {
  const items = fs.readdirSync(folderPath);
  for (const item of items) {
    // Exclude heavy or generated folders
    if (item === 'node_modules' || item === '.git' || item === 'dist' || item === '.DS_Store') continue;
    const fullPath = path.join(folderPath, item);
    const relPath = path.relative(rootDir, fullPath);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      addDirectoryToZip(zip, fullPath, rootDir);
    } else {
      const content = fs.readFileSync(fullPath);
      zip.file(relPath, content);
    }
  }
}

app.get('/api/download-zip', async (_req, res) => {
  try {
    const zip = new JSZip();
    const projectRoot = path.resolve(process.cwd(), '..');
    addDirectoryToZip(zip, projectRoot, projectRoot);
    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="warehouse-system.zip"');
    res.send(buffer);
  } catch (err: any) {
    console.error('Failed to generate zip:', err);
    res.status(500).json({ success: false, message: 'Failed to generate zip: ' + err.message });
  }
});

// Products CRUD
app.get('/api/products', (req, res) => {
  const { search, category, supplier, lowStockOnly } = req.query;
  let filtered = [...products];

  if (search && typeof search === 'string') {
    const q = search.toLowerCase().trim();
    filtered = filtered.filter(p => 
      p.id.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q) ||
      p.supplierName.toLowerCase().includes(q) ||
      p.locationCode.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
    );
  }

  if (category && typeof category === 'string' && category !== 'ALL') {
    filtered = filtered.filter(p => p.category === category);
  }

  if (supplier && typeof supplier === 'string' && supplier !== 'ALL') {
    filtered = filtered.filter(p => p.supplierId === supplier || p.supplierName === supplier);
  }

  if (lowStockOnly === 'true') {
    filtered = filtered.filter(p => p.quantity <= p.lowStockThreshold);
  }

  res.json({
    success: true,
    count: filtered.length,
    products: filtered
  });
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  if (!product) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }
  res.json({ success: true, product });
});

app.post('/api/products', (req, res) => {
  const {
    name,
    sku,
    category,
    price,
    quantity,
    unit = 'pcs',
    supplierId,
    locationId,
    lowStockThreshold = 20,
    description = ''
  } = req.body;

  if (!name || price === undefined || quantity === undefined) {
    return res.status(400).json({ success: false, message: 'Product Name, Price, and Quantity are required' });
  }

  const newId = `PRD-${1000 + products.length + 1}`;
  const supplier = suppliers.find(s => s.id === supplierId) || suppliers[0];
  const location = locations.find(l => l.id === locationId) || locations[0];

  const newProduct: Product = {
    id: newId,
    name: name.trim(),
    sku: sku ? sku.trim().toUpperCase() : `SKU-${Date.now().toString().slice(-6)}`,
    category: category || categories[0],
    price: Number(price),
    quantity: Number(quantity),
    unit,
    supplierId: supplier.id,
    supplierName: supplier.name,
    locationId: location.id,
    locationCode: location.code,
    lowStockThreshold: Number(lowStockThreshold),
    description: description.trim(),
    lastUpdated: new Date().toISOString()
  };

  products.unshift(newProduct);

  if (newProduct.quantity > 0) {
    stockMovements.unshift({
      id: `MOV-${Date.now().toString().slice(-4)}`,
      productId: newProduct.id,
      productName: newProduct.name,
      sku: newProduct.sku,
      type: 'INBOUND',
      quantity: newProduct.quantity,
      fromLocation: 'Initial Inventory Intake',
      toLocation: newProduct.locationCode,
      referenceNumber: `INIT-${newProduct.id}`,
      reason: 'Initial intake registration',
      timestamp: new Date().toISOString(),
      operator: 'Warehouse System Admin'
    });
  }

  res.status(201).json({ success: true, product: newProduct });
});

app.put('/api/products/:id', (req, res) => {
  const index = products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  const existing = products[index];
  const {
    name,
    sku,
    category,
    price,
    quantity,
    unit,
    supplierId,
    locationId,
    lowStockThreshold,
    description
  } = req.body;

  const supplier = supplierId ? (suppliers.find(s => s.id === supplierId) || suppliers[0]) : null;
  const location = locationId ? (locations.find(l => l.id === locationId) || locations[0]) : null;

  const oldQty = existing.quantity;
  const newQty = quantity !== undefined ? Number(quantity) : oldQty;
  if (newQty !== oldQty) {
    const diff = newQty - oldQty;
    stockMovements.unshift({
      id: `MOV-${Date.now().toString().slice(-4)}`,
      productId: existing.id,
      productName: name || existing.name,
      sku: sku || existing.sku,
      type: 'ADJUSTMENT',
      quantity: diff,
      fromLocation: existing.locationCode,
      toLocation: location ? location.code : existing.locationCode,
      referenceNumber: `ADJ-${existing.id}`,
      reason: 'Manual stock edit reconciliation',
      timestamp: new Date().toISOString(),
      operator: 'Warehouse Operator'
    });
  }

  products[index] = {
    ...existing,
    name: name !== undefined ? name.trim() : existing.name,
    sku: sku !== undefined ? sku.trim().toUpperCase() : existing.sku,
    category: category !== undefined ? category : existing.category,
    price: price !== undefined ? Number(price) : existing.price,
    quantity: newQty,
    unit: unit !== undefined ? unit : existing.unit,
    supplierId: supplier ? supplier.id : existing.supplierId,
    supplierName: supplier ? supplier.name : existing.supplierName,
    locationId: location ? location.id : existing.locationId,
    locationCode: location ? location.code : existing.locationCode,
    lowStockThreshold: lowStockThreshold !== undefined ? Number(lowStockThreshold) : existing.lowStockThreshold,
    description: description !== undefined ? description : existing.description,
    lastUpdated: new Date().toISOString()
  };

  res.json({ success: true, product: products[index] });
});

app.delete('/api/products/:id', (req, res) => {
  const index = products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  const deleted = products.splice(index, 1)[0];
  res.json({ success: true, message: 'Product deleted', product: deleted });
});

// Categories
app.get('/api/categories', (_req, res) => {
  res.json({ success: true, categories });
});

app.post('/api/categories', (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ success: false, message: 'Category name is required' });
  }
  const cleanName = name.trim();
  if (!categories.includes(cleanName)) {
    categories.push(cleanName);
  }
  res.json({ success: true, categories });
});

// Suppliers
app.get('/api/suppliers', (_req, res) => {
  res.json({ success: true, suppliers });
});

app.post('/api/suppliers', (req, res) => {
  const { name, contactPerson, email, phone, leadTimeDays = 5, rating = 4.8 } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ success: false, message: 'Supplier name is required' });
  }
  const id = `SUP-${String(suppliers.length + 1).padStart(3, '0')}`;
  const newSupplier: Supplier = {
    id,
    name: name.trim(),
    code: name.trim().slice(0, 3).toUpperCase(),
    contactPerson: contactPerson || 'Procurement Rep',
    email: email || `orders@${name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
    phone: phone || '+1 (555) 000-0000',
    leadTimeDays: Number(leadTimeDays) || 5,
    rating: Number(rating) || 4.8,
    status: 'ACTIVE'
  };
  suppliers.push(newSupplier);
  res.status(201).json({ success: true, supplier: newSupplier });
});

// Warehouse Locations
app.get('/api/locations', (_req, res) => {
  const updatedLocations = locations.map(loc => {
    const locProducts = products.filter(p => p.locationId === loc.id || p.locationCode === loc.code);
    const calculatedOccupancy = locProducts.reduce((sum, p) => sum + p.quantity, 0);
    const occupancy = Math.max(loc.currentOccupancy, calculatedOccupancy);
    let status: 'AVAILABLE' | 'FULL' | 'MAINTENANCE' = loc.status;
    if (occupancy >= loc.maxCapacity) {
      status = 'FULL';
    }
    return { ...loc, currentOccupancy: occupancy, status, productCount: locProducts.length };
  });

  res.json({ success: true, locations: updatedLocations });
});

app.post('/api/locations', (req, res) => {
  const { code, zone, aisle, rack, shelf, type, maxCapacity } = req.body;
  if (!code || !zone) {
    return res.status(400).json({ success: false, message: 'Location Code and Zone are required' });
  }

  const id = `LOC-${code.replace(/[^A-Za-z0-9]/g, '').toUpperCase()}`;
  const newLocation: WarehouseLocation = {
    id,
    code: code.trim().toUpperCase(),
    zone: zone.trim(),
    aisle: aisle || '01',
    rack: rack || '01',
    shelf: shelf || '01',
    type: type || 'BIN_SHELVING',
    maxCapacity: Number(maxCapacity) || 1000,
    currentOccupancy: 0,
    status: 'AVAILABLE'
  };

  locations.push(newLocation);
  res.status(201).json({ success: true, location: newLocation });
});

// Stock Movements (Entering, Moving Within, Leaving)
app.get('/api/stock-movements', (req, res) => {
  const { productId, type } = req.query;
  let list = [...stockMovements];
  if (productId && typeof productId === 'string') {
    list = list.filter(m => m.productId === productId);
  }
  if (type && typeof type === 'string' && type !== 'ALL') {
    list = list.filter(m => m.type === type);
  }
  res.json({ success: true, movements: list });
});

app.post('/api/stock-movements', (req, res) => {
  const { productId, type, quantity, fromLocation, toLocation, referenceNumber, reason, operator = 'Warehouse Specialist' } = req.body;
  
  if (!productId || !type || !quantity) {
    return res.status(400).json({ success: false, message: 'Product, Type, and Quantity are required' });
  }

  const product = products.find(p => p.id === productId);
  if (!product) {
    return res.status(404).json({ success: false, message: 'Product not found' });
  }

  const qty = Math.abs(Number(quantity));

  if (type === 'OUTBOUND' && product.quantity < qty) {
    return res.status(400).json({ success: false, message: `Insufficient inventory! Available: ${product.quantity}, Requested: ${qty}` });
  }

  if (type === 'INBOUND') {
    product.quantity += qty;
    if (toLocation) {
      product.locationCode = toLocation;
    }
  } else if (type === 'OUTBOUND') {
    product.quantity -= qty;
  } else if (type === 'INTERNAL_TRANSFER') {
    if (toLocation) {
      product.locationCode = toLocation;
      const targetLoc = locations.find(l => l.code === toLocation);
      if (targetLoc) {
        product.locationId = targetLoc.id;
      }
    }
  } else if (type === 'ADJUSTMENT') {
    const rawQty = Number(quantity);
    product.quantity = Math.max(0, product.quantity + rawQty);
  }
  product.lastUpdated = new Date().toISOString();

  const newMovement: StockMovement = {
    id: `MOV-${Date.now().toString().slice(-4)}`,
    productId: product.id,
    productName: product.name,
    sku: product.sku,
    type,
    quantity: type === 'ADJUSTMENT' ? Number(quantity) : (type === 'OUTBOUND' ? -qty : qty),
    fromLocation: fromLocation || product.locationCode,
    toLocation: toLocation || product.locationCode,
    referenceNumber: referenceNumber || `REF-${Date.now().toString().slice(-5)}`,
    reason: reason || 'Scheduled warehouse movement operation',
    timestamp: new Date().toISOString(),
    operator
  };

  stockMovements.unshift(newMovement);
  res.status(201).json({ success: true, movement: newMovement, updatedProduct: product });
});

// Purchase Orders (Inbound entering goods)
app.get('/api/purchase-orders', (_req, res) => {
  res.json({ success: true, purchaseOrders });
});

app.post('/api/purchase-orders', (req, res) => {
  const { supplierId, items, destinationLocationId, notes } = req.body;
  if (!supplierId || !items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ success: false, message: 'Supplier and at least 1 item are required' });
  }

  const supplier = suppliers.find(s => s.id === supplierId) || suppliers[0];
  const destLoc = locations.find(l => l.id === destinationLocationId) || locations[0];
  const orderNumber = `PO-2026-${100 + purchaseOrders.length + 1}`;
  
  const enrichedItems = items.map((it: any) => {
    const prod = products.find(p => p.id === it.productId);
    const qty = Number(it.quantity) || 10;
    const unitPrice = Number(it.unitPrice) || (prod ? prod.price * 0.75 : 10);
    return {
      productId: it.productId,
      productName: prod ? prod.name : 'Unknown Product',
      sku: prod ? prod.sku : 'SKU-GEN',
      quantity: qty,
      unitPrice,
      totalPrice: Number((qty * unitPrice).toFixed(2))
    };
  });

  const totalAmount = enrichedItems.reduce((acc: number, it: any) => acc + it.totalPrice, 0);
  const orderDate = new Date().toISOString();
  const deliveryDate = new Date(Date.now() + supplier.leadTimeDays * 86400000).toISOString();

  const newPO: PurchaseOrder = {
    id: orderNumber,
    orderNumber,
    supplierId: supplier.id,
    supplierName: supplier.name,
    status: 'PENDING',
    items: enrichedItems,
    totalAmount: Number(totalAmount.toFixed(2)),
    orderDate,
    expectedDeliveryDate: deliveryDate,
    destinationLocationId: destLoc.id,
    destinationLocationCode: destLoc.code,
    notes: notes || 'Standard replenishment order'
  };

  purchaseOrders.unshift(newPO);
  res.status(201).json({ success: true, purchaseOrder: newPO });
});

// Receive Purchase Order
app.post('/api/purchase-orders/:id/receive', (req, res) => {
  const po = purchaseOrders.find(p => p.id === req.params.id);
  if (!po) {
    return res.status(404).json({ success: false, message: 'Purchase Order not found' });
  }

  if (po.status === 'RECEIVED') {
    return res.status(400).json({ success: false, message: 'Purchase Order already received' });
  }

  po.status = 'RECEIVED';
  po.receivedDate = new Date().toISOString();

  const updatedProds: Product[] = [];
  po.items.forEach(item => {
    const prod = products.find(p => p.id === item.productId);
    if (prod) {
      prod.quantity += item.quantity;
      prod.lastUpdated = new Date().toISOString();
      updatedProds.push(prod);

      stockMovements.unshift({
        id: `MOV-${Date.now().toString().slice(-4)}-${item.productId.slice(-3)}`,
        productId: prod.id,
        productName: prod.name,
        sku: prod.sku,
        type: 'INBOUND',
        quantity: item.quantity,
        fromLocation: `${po.supplierName} (PO Delivery)`,
        toLocation: po.destinationLocationCode,
        referenceNumber: po.orderNumber,
        reason: `Goods receipt from ${po.orderNumber}`,
        timestamp: new Date().toISOString(),
        operator: 'Receiving Dock Supervisor'
      });
    }
  });

  res.json({ success: true, purchaseOrder: po, updatedProducts: updatedProds });
});

// Demand Forecasting
app.get('/api/forecast', (req, res) => {
  const { productId } = req.query;

  if (productId && typeof productId === 'string') {
    const prod = products.find(p => p.id === productId);
    if (!prod) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    const forecast = generateForecastData(prod);
    return res.json({ success: true, forecast });
  }

  const allForecasts = products.map(prod => generateForecastData(prod));
  const criticalCount = allForecasts.filter(f => f.riskLevel === 'CRITICAL_STOCKOUT').length;
  const warningCount = allForecasts.filter(f => f.riskLevel === 'LOW_STOCK_RISK').length;

  res.json({
    success: true,
    summary: {
      totalTrackedProducts: products.length,
      criticalStockoutRiskCount: criticalCount,
      lowStockWarningCount: warningCount,
      totalRecommendedRestockUnits: allForecasts.reduce((sum, f) => sum + (f.currentStock < f.reorderPoint ? f.recommendedRestockQty : 0), 0)
    },
    forecasts: allForecasts
  });
});

app.post('/api/forecast/ai-analyze', async (req, res) => {
  const { productId } = req.body;
  const targetProduct = productId ? products.find(p => p.id === productId) : null;
  const forecastItems = targetProduct ? [generateForecastData(targetProduct)] : products.map(p => generateForecastData(p));
  
  const highRiskItems = forecastItems.filter(f => f.riskLevel === 'CRITICAL_STOCKOUT' || f.riskLevel === 'LOW_STOCK_RISK');

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.json({
      success: true,
      mode: 'heuristic',
      summary: `Automated replenishment analysis identified ${highRiskItems.length} products needing prompt purchase orders to avoid running out of stock.`,
      actionItems: highRiskItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        urgency: item.riskLevel === 'CRITICAL_STOCKOUT' ? 'IMMEDIATE' : 'SCHEDULE_THIS_WEEK',
        daysRemaining: item.daysRemaining,
        recommendedPOQty: item.recommendedRestockQty,
        rationale: `Current stock of ${item.currentStock} units will deplete in ~${item.daysRemaining} days at daily sales velocity of ${item.avgDailyDemand} units/day. Lead time is ${item.leadTimeDays} days.`
      }))
    });
  }

  try {
    const ai = new GoogleGenAI();
    const prompt = `You are a warehouse optimization system. Analyze the following inventory demand and forecast metrics:
${JSON.stringify(highRiskItems.slice(0, 5), null, 2)}

Provide a concise 3-sentence summary of stockout risks, safety buffer adequacy, and top 2 immediate procurement priorities.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt
    });

    res.json({
      success: true,
      mode: 'gemini',
      summary: response.text || 'Forecast analysis completed.',
      actionItems: highRiskItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        urgency: item.riskLevel === 'CRITICAL_STOCKOUT' ? 'IMMEDIATE' : 'SCHEDULE_THIS_WEEK',
        daysRemaining: item.daysRemaining,
        recommendedPOQty: item.recommendedRestockQty,
        rationale: `Lead time is ${item.leadTimeDays} days with estimated ${item.daysRemaining} days of stock remaining.`
      }))
    });
  } catch (err: any) {
    console.error('Gemini forecast advisory error:', err);
    res.json({
      success: true,
      mode: 'heuristic_fallback',
      summary: `Inventory telemetry detected ${highRiskItems.length} products below safety levels. Rapid supplier PO dispatch recommended.`,
      actionItems: highRiskItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        urgency: item.riskLevel === 'CRITICAL_STOCKOUT' ? 'IMMEDIATE' : 'SCHEDULE_THIS_WEEK',
        daysRemaining: item.daysRemaining,
        recommendedPOQty: item.recommendedRestockQty,
        rationale: `Estimated runway of ${item.daysRemaining} days against supplier delivery cycle of ${item.leadTimeDays} days.`
      }))
    });
  }
});

// General Warehouse Stats
app.get('/api/stats', (_req, res) => {
  const totalProducts = products.length;
  const lowStockCount = products.filter(p => p.quantity <= p.lowStockThreshold).length;
  const outOfStockCount = products.filter(p => p.quantity === 0).length;
  const totalStockUnits = products.reduce((acc, p) => acc + p.quantity, 0);
  const totalValuation = products.reduce((acc, p) => acc + (p.quantity * p.price), 0);
  const pendingOrders = purchaseOrders.filter(p => p.status === 'PENDING' || p.status === 'IN_TRANSIT').length;
  const recentMovementsCount = stockMovements.length;

  res.json({
    success: true,
    stats: {
      totalProducts,
      lowStockCount,
      outOfStockCount,
      totalStockUnits,
      totalValuation: Number(totalValuation.toFixed(2)),
      pendingOrders,
      recentMovementsCount,
      totalLocations: locations.length,
      totalSuppliers: suppliers.length
    }
  });
});

// Backend only: the Vite frontend runs separately on port 5173.
app.get('/api/health', (_req, res) => {
  res.json({ success: true, message: 'Warehouse API is running' });
});

app.get('/api/health/db', async (_req, res) => {
  try {
    await checkDatabaseConnection();
    res.json({ success: true, message: 'MySQL connection successful' });
  } catch (error) {
    console.error('MySQL health check failed:', error);
    res.status(503).json({ success: false, message: 'MySQL connection failed. Check backend/.env and database setup.' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Warehouse API] running at http://localhost:${PORT}`);
});
