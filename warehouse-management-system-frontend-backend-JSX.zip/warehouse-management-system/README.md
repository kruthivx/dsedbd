# Apex Warehouse Management System (separated frontend and backend)

## Folder layout
- `frontend/`: React + Vite UI
- `backend/`: Express REST API
- `database/warehouse.sql`: starter MySQL schema

## Run in VS Code (Windows PowerShell)

### 1. Set up MySQL
1. Open MySQL Workbench and run `database/warehouse.sql`.
2. Copy `backend/.env.example` to `backend/.env`.
3. Edit `backend/.env` and set your MySQL password and optional Gemini API key.

### 2. Install and start backend (Terminal 1)
```powershell
cd backend
npm install
npm run dev
```
Backend runs at `http://localhost:5000`.

### 3. Install and start frontend (Terminal 2, project root)
```powershell
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`. Vite forwards `/api` requests to port 5000.

## Health checks
- API: `http://localhost:5000/api/health`
- MySQL connection: `http://localhost:5000/api/health/db`
- Frontend: `http://localhost:5173`

## Important database note
The existing UI and API logic has been preserved from the uploaded project. Product, supplier, location, movement, purchase-order, and user API handlers currently still use the original in-memory demo arrays. The MySQL schema and connection health check are included, but CRUD routes have **not yet been migrated to persist data in MySQL**. Do not present the current app as fully database-backed until that migration is completed.
