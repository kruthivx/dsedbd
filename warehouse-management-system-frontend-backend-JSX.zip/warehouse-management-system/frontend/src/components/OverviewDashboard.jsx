import React from 'react';
import { 
  Package, 
  AlertTriangle, 
  ShoppingCart, 
  ArrowRightLeft, 
  ArrowDownRight, 
  ArrowUpRight, 
  Layers, 
  TrendingUp, 
  Plus, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

export default function OverviewDashboard({
  stats,
  products = [],
  movements = [],
  locations = [],
  purchaseOrders = [],
  onNavigateTab,
  onAddProduct,
  onQuickMove,
  onCreatePOForProduct
}) {
  const lowStockProducts = products.filter(p => p.quantity <= p.lowStockThreshold);
  const recentMovements = movements.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              Warehouse Command &amp; Operations Dashboard
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Live operational telemetry of inventory intake, inter-bay relocations, dispatch fulfillment, and stock runway.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onQuickMove}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-slate-600" />
              <span>Log Stock Movement</span>
            </button>

            <button
              onClick={onAddProduct}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Product</span>
            </button>
          </div>
        </div>

        {/* 4 Primary KPI Cards */}
        <div className="mt-5 grid grid-cols-2 lg:grid-cols-4 gap-3 pt-4 border-t border-slate-100">
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Catalog SKUs</span>
              <Package className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">
              {stats?.totalProducts || products.length}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Across {locations.length} warehouse bins
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Total Units in Stock</span>
              <Layers className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">
              {stats?.totalStockUnits?.toLocaleString() || products.reduce((s, p) => s + p.quantity, 0).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Valuation: ${stats?.totalValuation?.toLocaleString() || '0.00'}
            </div>
          </div>

          <div className={`p-3.5 border rounded-lg ${
            lowStockProducts.length > 0 ? 'bg-amber-50/70 border-amber-200' : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span className="font-semibold text-amber-900">Low-Stock Warnings</span>
              <AlertTriangle className={`w-4 h-4 ${lowStockProducts.length > 0 ? 'text-amber-600' : 'text-slate-400'}`} />
            </div>
            <div className="text-xl font-bold text-amber-700 font-mono tabular-nums mt-1">
              {lowStockProducts.length} Items
            </div>
            <div className="text-[11px] text-amber-800 mt-0.5">
              {lowStockProducts.filter(p => p.quantity === 0).length} completely out of stock
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Inbound Purchase Orders</span>
              <ShoppingCart className="w-4 h-4 text-slate-400" />
            </div>
            <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">
              {purchaseOrders.filter(p => p.status === 'PENDING' || p.status === 'IN_TRANSIT').length} Active
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {purchaseOrders.filter(p => p.status === 'IN_TRANSIT').length} en route to dock
            </div>
          </div>
        </div>
      </div>

      {/* Low Stock Warning Banner & Rapid Actions */}
      {lowStockProducts.length > 0 && (
        <div className="bg-white border border-amber-200 rounded-lg p-4 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" />
              <h2 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                Replenishment Warning: Products Below Safety Limit ({lowStockProducts.length})
              </h2>
            </div>
            <button
              onClick={() => onNavigateTab('products')}
              className="text-xs text-amber-900 font-medium hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View all in Products Table</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {lowStockProducts.slice(0, 3).map((prod) => (
              <div 
                key={prod.id}
                className="p-3 bg-amber-50/50 border border-amber-200/80 rounded-md flex flex-col justify-between gap-2"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] text-slate-500">{prod.id}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-mono ${
                      prod.quantity === 0 ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {prod.quantity === 0 ? 'OUT OF STOCK' : `LOW: ${prod.quantity}/${prod.lowStockThreshold} MIN`}
                    </span>
                  </div>
                  <div className="font-semibold text-slate-900 text-xs mt-1">
                    {prod.name}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Bin: <span className="font-mono">{prod.locationCode}</span> · {prod.supplierName}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1 border-t border-amber-200/50">
                  <button
                    onClick={() => onNavigateTab('forecast')}
                    className="text-[11px] text-slate-700 hover:text-slate-900 underline cursor-pointer"
                  >
                    View Forecast
                  </button>
                  <button
                    onClick={() => onCreatePOForProduct(prod.id, 50)}
                    className="px-2.5 py-1 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded cursor-pointer"
                  >
                    Reorder PO
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Two Column Split: Live Movements Activity + Warehouse Zones */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Recent Stock Movements Feed (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Live Movement Audit Trail
              </h2>
              <p className="text-xs text-slate-500">
                Products entering, moving within, and leaving the warehouse.
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('movements')}
              className="text-xs text-slate-600 hover:text-slate-900 underline flex items-center gap-1 cursor-pointer"
            >
              <span>View All Movements</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {recentMovements.map((m) => {
              const isInbound = m.type === 'INBOUND';
              const isOutbound = m.type === 'OUTBOUND';
              const isTransfer = m.type === 'INTERNAL_TRANSFER';

              return (
                <div key={m.id} className="p-3.5 hover:bg-slate-50 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-md ${
                      isInbound ? 'bg-emerald-50 text-emerald-700' : isOutbound ? 'bg-amber-50 text-amber-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {isInbound && <ArrowDownRight className="w-4 h-4 text-emerald-600" />}
                      {isTransfer && <ArrowRightLeft className="w-4 h-4 text-slate-600" />}
                      {isOutbound && <ArrowUpRight className="w-4 h-4 text-amber-600" />}
                      {m.type === 'ADJUSTMENT' && <Package className="w-4 h-4 text-purple-600" />}
                    </div>

                    <div>
                      <div className="font-semibold text-slate-900">
                        {m.productName}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span className="font-mono text-slate-600">{m.fromLocation || 'Dock'} → {m.toLocation || 'Bin'}</span>
                        <span aria-hidden="true">·</span>
                        <span>{m.operator}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono text-slate-400">{m.referenceNumber}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className={`font-mono tabular-nums font-bold text-sm ${
                      isInbound ? 'text-emerald-700' : isOutbound ? 'text-amber-700' : 'text-slate-900'
                    }`}>
                      {m.quantity > 0 ? `+${m.quantity}` : m.quantity}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Warehouse Zones & Bins Meter (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Storage Zones &amp; Bay Capacity
              </h2>
              <p className="text-xs text-slate-500">
                Spatial utilization across active storage aisles.
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('locations')}
              className="text-xs text-slate-600 hover:text-slate-900 underline flex items-center gap-1 cursor-pointer"
            >
              <span>Manage Bins</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-3 pt-1">
            {locations.slice(0, 5).map((loc) => {
              const locProducts = products.filter(p => p.locationCode === loc.code || p.locationId === loc.id);
              const currentUnits = locProducts.reduce((sum, p) => sum + p.quantity, 0);
              const occupancyRate = Math.min(100, Math.round((currentUnits / loc.maxCapacity) * 100));

              return (
                <div key={loc.id} className="space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-medium text-slate-800">
                      <span className="font-mono font-bold text-slate-900">{loc.code}</span>
                      <span className="text-slate-400 truncate max-w-[140px]">{loc.zone}</span>
                    </div>
                    <span className="font-mono text-slate-500 tabular-nums">
                      {currentUnits} / {loc.maxCapacity} ({occupancyRate}%)
                    </span>
                  </div>

                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${
                        occupancyRate >= 85 ? 'bg-amber-500' : 'bg-slate-900'
                      }`}
                      style={{ width: `${occupancyRate}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
