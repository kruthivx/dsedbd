import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  AlertTriangle, 
  Calendar, 
  ArrowRight, 
  Sparkles, 
  RefreshCw, 
  CheckCircle2, 
  Package, 
  Layers,
  ChevronRight,
  ShieldCheck,
  Clock
} from 'lucide-react';
import { api } from '../services/api';

export default function DemandForecastView({ onCreatePOForProduct, onRefreshNeeded }) {
  const [forecasts, setForecasts] = useState([]);
  const [summary, setSummary] = useState(null);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchForecast = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await api.getForecast();
      if (data.success) {
        setForecasts(data.forecasts || []);
        setSummary(data.summary || null);
        if (data.forecasts?.length > 0 && !selectedProductId) {
          // Select high risk product by default if exists
          const highRisk = data.forecasts.find(f => f.riskLevel === 'CRITICAL_STOCKOUT') || data.forecasts[0];
          setSelectedProductId(highRisk.productId);
        }
      }
    } catch (err) {
      setError(err.message || 'Failed to load forecast model');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchForecast();
  }, []);

  const handleRunAIAnalysis = async () => {
    try {
      setAiLoading(true);
      const res = await api.analyzeForecastAI(selectedProductId);
      if (res.success) {
        setAiAnalysis(res);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  const selectedForecast = forecasts.find(f => f.productId === selectedProductId) || forecasts[0];

  // SVG Chart Dimensions & Computations
  const renderTrendChart = (forecast) => {
    if (!forecast) return null;
    const history = forecast.historicalWeeks || [];
    const future = forecast.forecastWeeks || [];
    const allPoints = [...history, ...future];
    const maxVal = Math.max(...allPoints.map(p => p.demand), 10) * 1.25;

    const chartHeight = 160;
    const chartWidth = 540;
    const paddingX = 40;
    const paddingY = 25;
    const usableWidth = chartWidth - paddingX * 2;
    const usableHeight = chartHeight - paddingY * 2;

    const stepX = usableWidth / (allPoints.length - 1);

    // Compute coordinate points
    const points = allPoints.map((item, index) => {
      const x = paddingX + index * stepX;
      const y = chartHeight - paddingY - (item.demand / maxVal) * usableHeight;
      return { x, y, demand: item.demand, label: item.week, isForecast: index >= history.length };
    });

    const historyPoints = points.slice(0, history.length);
    const forecastPoints = points.slice(history.length - 1); // overlap last history point for continuity

    const historyPath = historyPoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
    const forecastPath = forecastPoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

    return (
      <div className="w-full overflow-x-auto">
        <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-44 select-none">
          {/* Horizontal gridlines */}
          {[0, 0.5, 1].map((ratio, idx) => {
            const y = chartHeight - paddingY - ratio * usableHeight;
            const val = Math.round(ratio * maxVal);
            return (
              <g key={idx}>
                <line x1={paddingX} y1={y} x2={chartWidth - paddingX} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
                <text x={paddingX - 8} y={y + 3} textAnchor="end" className="text-[9px] fill-slate-400 font-mono">
                  {val}
                </text>
              </g>
            );
          })}

          {/* Historical Area fill */}
          {historyPoints.length > 1 && (
            <path
              d={`${historyPath} L ${historyPoints[historyPoints.length - 1].x} ${chartHeight - paddingY} L ${historyPoints[0].x} ${chartHeight - paddingY} Z`}
              fill="#0f172a"
              fillOpacity="0.06"
            />
          )}

          {/* Forecast Area fill */}
          {forecastPoints.length > 1 && (
            <path
              d={`${forecastPath} L ${forecastPoints[forecastPoints.length - 1].x} ${chartHeight - paddingY} L ${forecastPoints[0].x} ${chartHeight - paddingY} Z`}
              fill="#f59e0b"
              fillOpacity="0.12"
            />
          )}

          {/* Divider between history & forecast */}
          {historyPoints.length > 0 && (
            <line
              x1={historyPoints[historyPoints.length - 1].x}
              y1={paddingY}
              x2={historyPoints[historyPoints.length - 1].x}
              y2={chartHeight - paddingY}
              stroke="#cbd5e1"
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />
          )}

          {/* History line */}
          <path d={historyPath} fill="none" stroke="#0f172a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

          {/* Forecast line (dashed amber) */}
          <path d={forecastPath} fill="none" stroke="#d97706" strokeWidth="2.5" strokeDasharray="5 4" strokeLinecap="round" strokeLinejoin="round" />

          {/* Points */}
          {points.map((pt, idx) => (
            <g key={idx}>
              <circle
                cx={pt.x}
                cy={pt.y}
                r="3.5"
                fill={pt.isForecast ? '#d97706' : '#0f172a'}
                stroke="#ffffff"
                strokeWidth="1.5"
              />
              <text
                x={pt.x}
                y={chartHeight - 6}
                textAnchor="middle"
                className={`text-[9px] font-mono ${pt.isForecast ? 'fill-amber-700 font-semibold' : 'fill-slate-500'}`}
              >
                {pt.label}
              </text>
            </g>
          ))}
        </svg>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header banner */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-500/10 text-amber-800 rounded-md">
                <TrendingUp className="w-5 h-5 text-amber-600" />
              </span>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Demand Forecasting &amp; Replenishment Engine
              </h1>
            </div>
            <p className="text-xs text-slate-500 mt-1 max-w-2xl">
              Quantitative velocity modeling, seasonal trend projection, lead-time safety stock computation ($SS = Z \times \sigma_d \times \sqrt{L}$), and automatic reorder point (ROP) calculation.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={fetchForecast}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-600" />
              <span>Recalculate Models</span>
            </button>

            <button
              onClick={handleRunAIAnalysis}
              disabled={aiLoading}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-900 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-md shadow-xs transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>{aiLoading ? 'Auditing Replenishment...' : 'Strategic AI Insights'}</span>
            </button>
          </div>
        </div>

        {/* Forecast KPI Strip */}
        {summary && (
          <div className="mt-5 grid grid-cols-2 md:grid-cols-4 gap-3 pt-4 border-t border-slate-100">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <div className="text-[11px] font-medium text-slate-500">Tracked SKUs</div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                {summary.totalTrackedProducts}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Continuous velocity analysis</div>
            </div>

            <div className={`p-3 border rounded-lg ${
              summary.criticalStockoutRiskCount > 0 ? 'bg-red-50 border-red-200' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="text-[11px] font-medium text-slate-600 flex items-center justify-between">
                <span>Critical Stockout Risk</span>
                <AlertTriangle className={`w-3.5 h-3.5 ${summary.criticalStockoutRiskCount > 0 ? 'text-red-600' : 'text-slate-400'}`} />
              </div>
              <div className={`text-lg font-bold font-mono tabular-nums mt-0.5 ${summary.criticalStockoutRiskCount > 0 ? 'text-red-700' : 'text-slate-900'}`}>
                {summary.criticalStockoutRiskCount} SKUs
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Runway &lt; Supplier lead time</div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <div className="text-[11px] font-medium text-slate-500">Low Stock Warnings</div>
              <div className="text-lg font-bold text-amber-700 font-mono tabular-nums mt-0.5">
                {summary.lowStockWarningCount} SKUs
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">At or below reorder threshold</div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <div className="text-[11px] font-medium text-slate-500">Recommended Restock Qty</div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                {summary.totalRecommendedRestockUnits?.toLocaleString()} units
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">EOQ aggregated reorders</div>
            </div>
          </div>
        )}
      </div>

      {/* AI Strategic Analysis Box (if generated) */}
      {aiAnalysis && (
        <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-700" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900">
                Replenishment Audit &amp; Priority Directives
              </h3>
            </div>
            <span className="text-[11px] text-amber-800 font-mono">
              Engine: {aiAnalysis.mode === 'gemini' ? 'Gemini 2.5 Flash' : 'Supply-Chain Heuristics'}
            </span>
          </div>
          <p className="text-xs text-slate-800 leading-relaxed">
            {aiAnalysis.summary}
          </p>

          {aiAnalysis.actionItems?.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-2">
              {aiAnalysis.actionItems.map((item, idx) => (
                <div key={idx} className="p-2.5 bg-white border border-amber-200/80 rounded-md text-xs flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-slate-900 flex items-center gap-2">
                      <span>{item.productName}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold font-mono ${
                        item.urgency === 'IMMEDIATE' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {item.urgency}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Runway: ~{item.daysRemaining} days · Recommended PO: <strong className="text-slate-800 font-mono">{item.recommendedPOQty} units</strong>
                    </div>
                  </div>
                  <button
                    onClick={() => onCreatePOForProduct(item.productId, item.recommendedPOQty)}
                    className="shrink-0 px-2.5 py-1 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded cursor-pointer"
                  >
                    Create PO
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Main Split: Detailed Selected Product Chart + All Forecasts Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Focused SKU Demand Decomposition (5 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Focused SKU Analysis
              </span>
              <h2 className="text-base font-bold text-slate-900 mt-0.5">
                {selectedForecast?.productName}
              </h2>
            </div>
            <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded text-slate-700">
              {selectedForecast?.productId}
            </span>
          </div>

          {/* SVG Chart */}
          <div className="bg-slate-50/70 p-3 rounded-lg border border-slate-200/80">
            <div className="flex items-center justify-between text-xs mb-2">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1.5 text-slate-700">
                  <span className="w-2.5 h-0.5 bg-slate-900 inline-block" />
                  <span>8-Wk Actuals</span>
                </span>
                <span className="flex items-center gap-1.5 text-amber-700 font-medium">
                  <span className="w-2.5 h-0.5 bg-amber-500 inline-block border-b border-dashed" />
                  <span>4-Wk Projected</span>
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Weekly Demand (units)</span>
            </div>

            {renderTrendChart(selectedForecast)}
          </div>

          {/* Math & Supply Chain Variables Breakdown */}
          {selectedForecast && (
            <div className="space-y-3 pt-2 text-xs">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[11px] text-slate-500">Current On-Hand</div>
                  <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                    {selectedForecast.currentStock} units
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[11px] text-slate-500">Daily Consumption (d)</div>
                  <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                    ~{selectedForecast.avgDailyDemand} units/day
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[11px] text-slate-500">Supplier Lead Time (L)</div>
                  <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                    {selectedForecast.leadTimeDays} days
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[11px] text-slate-500">Safety Stock (SS)</div>
                  <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                    {selectedForecast.safetyStock} units (95% SL)
                  </div>
                </div>

                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="text-[11px] text-slate-500">Reorder Point (ROP)</div>
                  <div className="text-sm font-bold font-mono tabular-nums text-amber-700 mt-0.5">
                    {selectedForecast.reorderPoint} units
                  </div>
                </div>

                <div className={`p-2.5 rounded border ${
                  selectedForecast.daysRemaining <= selectedForecast.leadTimeDays
                    ? 'bg-red-50 border-red-200 text-red-900'
                    : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}>
                  <div className="text-[11px] text-slate-500">Estimated Runway</div>
                  <div className="text-sm font-bold font-mono tabular-nums mt-0.5">
                    {selectedForecast.daysRemaining} Days
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                <button
                  onClick={() => onCreatePOForProduct(selectedForecast.productId, selectedForecast.recommendedRestockQty)}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer"
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>Create Restock PO for {selectedForecast.recommendedRestockQty} units</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Complete SKU Forecast & Risk Matrix Table (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Product Demand Forecast &amp; Reorder Matrix
              </h3>
              <p className="text-xs text-slate-500">
                Click any product to inspect historical consumption &amp; forward curve.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Product</th>
                  <th className="py-2.5 px-3 text-right">Stock</th>
                  <th className="py-2.5 px-3 text-right">Daily Burn</th>
                  <th className="py-2.5 px-3 text-right">Runway</th>
                  <th className="py-2.5 px-3 text-right" title="Reorder Point (ROP): The stock level that triggers reordering so you don't run out">
                    Reorder Point (ROP)
                  </th>
                  <th className="py-2.5 px-3">Risk Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {forecasts.map((f) => {
                  const isSelected = f.productId === selectedProductId;
                  const isCritical = f.riskLevel === 'CRITICAL_STOCKOUT';
                  const isWarning = f.riskLevel === 'LOW_STOCK_RISK';

                  return (
                    <tr
                      key={f.productId}
                      onClick={() => setSelectedProductId(f.productId)}
                      className={`hover:bg-slate-50 cursor-pointer transition-colors ${
                        isSelected ? 'bg-slate-100/70 font-medium' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-slate-900">{f.productName}</div>
                        <div className="text-[11px] font-mono text-slate-400">{f.productId} · {f.category}</div>
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                        {f.currentStock}
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                        {f.avgDailyDemand}/d
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold">
                        <span className={isCritical ? 'text-red-600' : isWarning ? 'text-amber-700' : 'text-slate-800'}>
                          {f.daysRemaining}d
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                        {f.reorderPoint}
                      </td>

                      <td className="py-2.5 px-3">
                        {isCritical ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">
                            <AlertTriangle className="w-2.5 h-2.5" />
                            CRITICAL
                          </span>
                        ) : isWarning ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                            LOW RUNWAY
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                            HEALTHY
                          </span>
                        )}
                      </td>

                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onCreatePOForProduct(f.productId, f.recommendedRestockQty);
                          }}
                          className="px-2 py-1 text-[11px] font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                        >
                          Restock
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
