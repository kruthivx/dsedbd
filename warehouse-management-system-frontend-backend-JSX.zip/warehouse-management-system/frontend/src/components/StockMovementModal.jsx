import React, { useState, useEffect } from 'react';
import { X, ArrowRightLeft, ArrowDownRight, ArrowUpRight, Check } from 'lucide-react';

export default function StockMovementModal({
  isOpen,
  onClose,
  onSubmit,
  products = [],
  locations = [],
  preselectedProduct = null
}) {
  const [formData, setFormData] = useState({
    productId: '',
    type: 'INTERNAL_TRANSFER', // 'INBOUND' | 'INTERNAL_TRANSFER' | 'OUTBOUND' | 'ADJUSTMENT'
    quantity: '',
    fromLocation: '',
    toLocation: '',
    referenceNumber: '',
    reason: '',
    operator: 'WMS Operator'
  });

  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (preselectedProduct) {
      setFormData(prev => ({
        ...prev,
        productId: preselectedProduct.id,
        fromLocation: preselectedProduct.locationCode || '',
        toLocation: locations[0]?.code || '',
        referenceNumber: `MOV-${Date.now().toString().slice(-5)}`
      }));
    } else if (products.length > 0 && !formData.productId) {
      setFormData(prev => ({
        ...prev,
        productId: products[0].id,
        fromLocation: products[0].locationCode || '',
        toLocation: locations[0]?.code || '',
        referenceNumber: `MOV-${Date.now().toString().slice(-5)}`
      }));
    }
  }, [preselectedProduct, products, locations, isOpen]);

  if (!isOpen) return null;

  const selectedProd = products.find(p => p.id === formData.productId);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const qty = Number(formData.quantity);
    if (!qty || qty <= 0) {
      setError('Please enter a valid quantity greater than 0.');
      return;
    }

    if (formData.type === 'OUTBOUND' && selectedProd && selectedProd.quantity < qty) {
      setError(`Cannot dispatch ${qty} units. Current stock is only ${selectedProd.quantity} ${selectedProd.unit}.`);
      return;
    }

    try {
      setSubmitting(true);
      await onSubmit({
        ...formData,
        quantity: qty
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to log stock movement');
    } finally {
      setSubmitting(false);
    }
  };

  const handleProductChange = (prodId) => {
    const p = products.find(prod => prod.id === prodId);
    setFormData(prev => ({
      ...prev,
      productId: prodId,
      fromLocation: p ? p.locationCode : prev.fromLocation
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-lg w-full p-6 space-y-4 my-8">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Log Warehouse Stock Movement
            </h2>
            <p className="text-xs text-slate-500">
              Track products entering, relocating internally, or leaving the facility.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-md text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Movement Type Radio Grid */}
          <div>
            <label className="block font-medium text-slate-700 mb-1.5">
              Movement Classification
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className={`p-2.5 border rounded-md cursor-pointer flex items-center gap-2 transition-colors ${
                formData.type === 'INBOUND' ? 'border-emerald-500 bg-emerald-50/50 text-emerald-950 font-medium' : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="type"
                  value="INBOUND"
                  checked={formData.type === 'INBOUND'}
                  onChange={() => setFormData({ ...formData, type: 'INBOUND', fromLocation: 'Supplier Dock Intake' })}
                  className="sr-only"
                />
                <ArrowDownRight className="w-4 h-4 text-emerald-600" />
                <div>
                  <div className="font-semibold text-xs">Entering (Inbound)</div>
                  <div className="text-[10px] text-slate-500">Goods receipt, intake</div>
                </div>
              </label>

              <label className={`p-2.5 border rounded-md cursor-pointer flex items-center gap-2 transition-colors ${
                formData.type === 'INTERNAL_TRANSFER' ? 'border-slate-900 bg-slate-100 text-slate-900 font-medium' : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="type"
                  value="INTERNAL_TRANSFER"
                  checked={formData.type === 'INTERNAL_TRANSFER'}
                  onChange={() => setFormData({ ...formData, type: 'INTERNAL_TRANSFER' })}
                  className="sr-only"
                />
                <ArrowRightLeft className="w-4 h-4 text-slate-700" />
                <div>
                  <div className="font-semibold text-xs">Moving Within</div>
                  <div className="text-[10px] text-slate-500">Aisle to bay transfer</div>
                </div>
              </label>

              <label className={`p-2.5 border rounded-md cursor-pointer flex items-center gap-2 transition-colors ${
                formData.type === 'OUTBOUND' ? 'border-amber-500 bg-amber-50/50 text-amber-950 font-medium' : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="type"
                  value="OUTBOUND"
                  checked={formData.type === 'OUTBOUND'}
                  onChange={() => setFormData({ ...formData, type: 'OUTBOUND', toLocation: 'Dispatch Lane / Freight' })}
                  className="sr-only"
                />
                <ArrowUpRight className="w-4 h-4 text-amber-600" />
                <div>
                  <div className="font-semibold text-xs">Leaving (Outbound)</div>
                  <div className="text-[10px] text-slate-500">Dispatch, order fulfillment</div>
                </div>
              </label>

              <label className={`p-2.5 border rounded-md cursor-pointer flex items-center gap-2 transition-colors ${
                formData.type === 'ADJUSTMENT' ? 'border-slate-400 bg-slate-50 text-slate-800 font-medium' : 'border-slate-200 hover:bg-slate-50'
              }`}>
                <input
                  type="radio"
                  name="type"
                  value="ADJUSTMENT"
                  checked={formData.type === 'ADJUSTMENT'}
                  onChange={() => setFormData({ ...formData, type: 'ADJUSTMENT' })}
                  className="sr-only"
                />
                <Check className="w-4 h-4 text-slate-600" />
                <div>
                  <div className="font-semibold text-xs">Adjustment</div>
                  <div className="text-[10px] text-slate-500">Cycle count reconcile</div>
                </div>
              </label>
            </div>
          </div>

          {/* Product Selection */}
          <div>
            <label className="block font-medium text-slate-700 mb-1">
              Select Product
            </label>
            <select
              value={formData.productId}
              onChange={(e) => handleProductChange(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.id}) · On Hand: {p.quantity} {p.unit} · Location: {p.locationCode}
                </option>
              ))}
            </select>
          </div>

          {/* Quantity & Reference */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Quantity to Move <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                required
                placeholder="Units count"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                className="w-full px-3 py-2 font-mono tabular-nums border border-slate-200 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
              {selectedProd && (
                <span className="text-[11px] text-slate-500 mt-0.5 block">
                  Available in stock: <strong>{selectedProd.quantity} {selectedProd.unit}</strong>
                </span>
              )}
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Reference / Tracking ID
              </label>
              <input
                type="text"
                placeholder="e.g. PO-890, SO-123, INT-44"
                value={formData.referenceNumber}
                onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
                className="w-full px-3 py-2 font-mono uppercase border border-slate-200 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>

          {/* Location Routing */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                From Location
              </label>
              <input
                type="text"
                value={formData.fromLocation}
                onChange={(e) => setFormData({ ...formData, fromLocation: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                To Location / Bin
              </label>
              {formData.type === 'INTERNAL_TRANSFER' ? (
                <select
                  value={formData.toLocation}
                  onChange={(e) => setFormData({ ...formData, toLocation: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-mono focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
                >
                  {locations.map((loc) => (
                    <option key={loc.id} value={loc.code}>
                      {loc.code} ({loc.zone})
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  value={formData.toLocation}
                  onChange={(e) => setFormData({ ...formData, toLocation: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                />
              )}
            </div>
          </div>

          {/* Reason & Operator */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Reason / Purpose
              </label>
              <input
                type="text"
                placeholder="e.g. Rack replenishment, customer shipment"
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Operator
              </label>
              <input
                type="text"
                value={formData.operator}
                onChange={(e) => setFormData({ ...formData, operator: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs cursor-pointer"
            >
              {submitting ? 'Recording...' : 'Record Movement'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
