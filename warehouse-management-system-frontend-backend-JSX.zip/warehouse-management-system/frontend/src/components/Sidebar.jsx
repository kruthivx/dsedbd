import React from 'react';
import { 
  Package, 
  TrendingUp, 
  ArrowLeftRight, 
  ShoppingCart, 
  Layers, 
  Users, 
  LayoutDashboard,
  AlertTriangle
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, stats }) {
  const menu = [
    { id: 'overview', label: 'Operations Overview', icon: LayoutDashboard },
    { 
      id: 'products', 
      label: 'Products & Inventory', 
      icon: Package, 
      badge: stats?.lowStockCount > 0 ? stats.lowStockCount : null,
      badgeColor: 'amber'
    },
    { id: 'forecast', label: 'Demand Forecasting', icon: TrendingUp },
    { id: 'movements', label: 'Stock Movements', icon: ArrowLeftRight },
    { 
      id: 'purchase-orders', 
      label: 'Purchase Orders', 
      icon: ShoppingCart,
      badge: stats?.pendingOrders > 0 ? stats.pendingOrders : null,
      badgeColor: 'slate'
    },
    { id: 'locations', label: 'Warehouse Locations', icon: Layers },
    { id: 'suppliers', label: 'Suppliers Directory', icon: Users }
  ];

  return (
    <aside className="w-64 shrink-0 bg-white border-r border-slate-200 hidden md:flex flex-col justify-between min-h-[calc(100vh-57px)] p-4">
      <div className="space-y-6">
        <div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3">
            Core Modules
          </span>
          <nav className="mt-2 space-y-1">
            {menu.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        isActive
                          ? 'bg-slate-800 text-amber-300'
                          : item.badgeColor === 'amber'
                          ? 'bg-amber-100 text-amber-800 font-mono'
                          : 'bg-slate-100 text-slate-700 font-mono'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick Warehouse Capacity Metric */}
        {stats && (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
              <span>Total Units Stored</span>
              <span className="font-semibold text-slate-900 font-mono tabular-nums">
                {stats.totalStockUnits?.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Inventory Valuation</span>
              <span className="font-semibold text-slate-900 font-mono tabular-nums">
                ${stats.totalValuation?.toLocaleString()}
              </span>
            </div>
            {stats.lowStockCount > 0 && (
              <div className="mt-2.5 pt-2 border-t border-slate-200 flex items-center gap-1.5 text-xs text-amber-800">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>{stats.lowStockCount} items below safety limit</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="pt-4 border-t border-slate-200 text-[11px] text-slate-500 flex flex-col gap-2">
        <div>
          <span className="font-semibold text-slate-800 block">Warehouse System v1.2</span>
          <span>Central Inventory &amp; Logistics Hub</span>
        </div>
      </div>
    </aside>
  );
}
