import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  ArrowUpDown, 
  Download, 
  MapPin, 
  Layers, 
  PackageCheck,
  ArrowRightLeft,
  X
} from 'lucide-react';

export default function ProductsTable({
  products = [],
  categories = [],
  suppliers = [],
  locations = [],
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onLogMovement,
  loading
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedSupplier, setSelectedSupplier] = useState('ALL');
  const [selectedLocation, setSelectedLocation] = useState('ALL');
  const [stockStatusFilter, setStockStatusFilter] = useState('ALL'); // 'ALL' | 'LOW_STOCK' | 'OUT_OF_STOCK' | 'NORMAL'
  const [sortField, setSortField] = useState('id'); // 'id' | 'name' | 'price' | 'quantity'
  const [sortDirection, setSortDirection] = useState('asc');
  const [deleteConfirmProduct, setDeleteConfirmProduct] = useState(null);

  // Sorting handler
  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filtered and Sorted products
  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Search query
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      result = result.filter(p => 
        p.id.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.supplierName.toLowerCase().includes(q) ||
        p.locationCode.toLowerCase().includes(q)
      );
    }

    // Category filter
    if (selectedCategory !== 'ALL') {
      result = result.filter(p => p.category === selectedCategory);
    }

    // Supplier filter
    if (selectedSupplier !== 'ALL') {
      result = result.filter(p => p.supplierId === selectedSupplier || p.supplierName === selectedSupplier);
    }

    // Location filter
    if (selectedLocation !== 'ALL') {
      result = result.filter(p => p.locationId === selectedLocation || p.locationCode === selectedLocation);
    }

    // Stock Status filter
    if (stockStatusFilter === 'LOW_STOCK') {
      result = result.filter(p => p.quantity <= p.lowStockThreshold && p.quantity > 0);
    } else if (stockStatusFilter === 'OUT_OF_STOCK') {
      result = result.filter(p => p.quantity === 0);
    } else if (stockStatusFilter === 'NORMAL') {
      result = result.filter(p => p.quantity > p.lowStockThreshold);
    }

    // Sorting
    result.sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];
      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();

      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [products, searchTerm, selectedCategory, selectedSupplier, selectedLocation, stockStatusFilter, sortField, sortDirection]);

  // Export current view to CSV
  const exportToCSV = () => {
    const headers = ['Product ID,Product Name,SKU,Category,Price,Quantity,Unit,Supplier,Location,Low Stock Threshold'];
    const rows = filteredProducts.map(p => 
      `"${p.id}","${p.name}","${p.sku}","${p.category}","${p.price}","${p.quantity}","${p.unit}","${p.supplierName}","${p.locationCode}","${p.lowStockThreshold}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `warehouse_products_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const lowStockCountTotal = products.filter(p => p.quantity <= p.lowStockThreshold).length;

  return (
    <div className="space-y-4">
      {/* Top Controls Toolbar */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Products &amp; Inventory Directory
              </h1>
              <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                {filteredProducts.length} of {products.length} Items
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Comprehensive inventory tracking across storage zones, bin assignments, and active replenishment limits.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportToCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Export CSV</span>
            </button>

            {/* ADD PRODUCT BUTTON */}
            <button
              onClick={onAddProduct}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Product</span>
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search Box */}
          <div className="lg:col-span-2 relative">
            <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ID, name, SKU, supplier, location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-8 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Filter */}
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Supplier Filter */}
          <div>
            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
            >
              <option value="ALL">All Suppliers</option>
              {suppliers.map((sup) => (
                <option key={sup.id} value={sup.id}>
                  {sup.name}
                </option>
              ))}
            </select>
          </div>

          {/* Stock Status Filter */}
          <div>
            <select
              value={stockStatusFilter}
              onChange={(e) => setStockStatusFilter(e.target.value)}
              className={`w-full py-1.5 px-2.5 text-xs border rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer ${
                stockStatusFilter === 'LOW_STOCK'
                  ? 'bg-amber-50 border-amber-300 text-amber-900 font-semibold'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              <option value="ALL">All Stock Statuses</option>
              <option value="LOW_STOCK">⚠️ Low Stock Warning ({lowStockCountTotal})</option>
              <option value="OUT_OF_STOCK">🚨 Out of Stock</option>
              <option value="NORMAL">✅ Healthy Inventory</option>
            </select>
          </div>
        </div>

        {/* Active Filters Badges & Reset */}
        {(searchTerm || selectedCategory !== 'ALL' || selectedSupplier !== 'ALL' || selectedLocation !== 'ALL' || stockStatusFilter !== 'ALL') && (
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-slate-700">Active filters:</span>
              {searchTerm && <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700 font-mono">"{searchTerm}"</span>}
              {selectedCategory !== 'ALL' && <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700">{selectedCategory}</span>}
              {selectedSupplier !== 'ALL' && <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700">{suppliers.find(s => s.id === selectedSupplier)?.name}</span>}
              {stockStatusFilter !== 'ALL' && <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-medium">{stockStatusFilter.replace('_', ' ')}</span>}
            </div>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('ALL');
                setSelectedSupplier('ALL');
                setSelectedLocation('ALL');
                setStockStatusFilter('ALL');
              }}
              className="text-slate-500 hover:text-slate-900 underline cursor-pointer"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>

      {/* Main Table Card */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th 
                  onClick={() => handleSort('id')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Product ID</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('name')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Product Name</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-4">Category</th>
                <th 
                  onClick={() => handleSort('price')}
                  className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors select-none"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Price</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('quantity')}
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors select-none"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Quantity</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-4">Supplier</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {loading && products.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-6 h-6 border-2 border-slate-300 border-t-slate-900 rounded-full animate-spin" />
                      <span>Loading warehouse inventory...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <Layers className="w-8 h-8 text-slate-300" />
                      <p className="text-sm font-medium text-slate-600">No products match the selected criteria</p>
                      <button
                        onClick={onAddProduct}
                        className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add New Product</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => {
                  const isOutOfStock = product.quantity === 0;
                  const isLowStock = product.quantity <= product.lowStockThreshold && !isOutOfStock;

                  return (
                    <tr 
                      key={product.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isOutOfStock ? 'bg-red-50/30' : isLowStock ? 'bg-amber-50/20' : ''
                      }`}
                    >
                      {/* Product ID */}
                      <td className="py-3 px-4 font-mono font-medium text-slate-900 tabular-nums">
                        {product.id}
                      </td>

                      {/* Product Name & SKU */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">
                          {product.name}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          {product.sku}
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4">
                        <span className="text-slate-600 font-medium">
                          {product.category}
                        </span>
                      </td>

                      {/* Price */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                        ${product.price.toFixed(2)}
                      </td>

                      {/* Quantity WITH LOW STOCK WARNING LABEL */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className={`font-mono tabular-nums font-bold text-sm ${
                            isOutOfStock 
                              ? 'text-red-600' 
                              : isLowStock 
                              ? 'text-amber-700' 
                              : 'text-slate-900'
                          }`}>
                            {product.quantity.toLocaleString()} {product.unit}
                          </span>

                          {/* Low Stock Warning Label */}
                          {isOutOfStock ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold text-red-700 bg-red-100 border border-red-200 rounded">
                              <AlertTriangle className="w-3 h-3 text-red-600 shrink-0" />
                              <span>OUT OF STOCK</span>
                            </span>
                          ) : isLowStock ? (
                            <span 
                              title={`Low stock alert: Remaining ${product.quantity} ${product.unit} is at or below threshold of ${product.lowStockThreshold} ${product.unit}`}
                              className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold text-amber-800 bg-amber-100 border border-amber-200 rounded"
                            >
                              <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                              <span>LOW STOCK ({product.quantity}/{product.lowStockThreshold} min)</span>
                            </span>
                          ) : (
                            <span className="text-[11px] text-emerald-700 font-medium hidden xl:inline">
                              ✓ Normal
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Supplier */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">
                          {product.supplierName}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {product.supplierId}
                        </div>
                      </td>

                      {/* Location */}
                      <td className="py-3 px-4">
                        <div className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 border border-slate-200 rounded text-slate-800 font-mono font-medium text-xs">
                          <MapPin className="w-3 h-3 text-slate-500" />
                          <span>{product.locationCode}</span>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center justify-end gap-1">
                          {/* Quick Movement */}
                          <button
                            onClick={() => onLogMovement(product)}
                            title="Move / Adjust Stock"
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                          >
                            <ArrowRightLeft className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit Product */}
                          <button
                            onClick={() => onEditProduct(product)}
                            title="Edit Product Details"
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete Product */}
                          <button
                            onClick={() => setDeleteConfirmProduct(product)}
                            title="Delete Product"
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Summary Bar */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span>
              Showing <strong className="text-slate-900 font-mono tabular-nums">{filteredProducts.length}</strong> items
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>
              Total Units: <strong className="text-slate-900 font-mono tabular-nums">{filteredProducts.reduce((sum, p) => sum + p.quantity, 0).toLocaleString()}</strong>
            </span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>
              Value: <strong className="text-slate-900 font-mono tabular-nums">${filteredProducts.reduce((sum, p) => sum + (p.price * p.quantity), 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
            </span>
          </div>

          {lowStockCountTotal > 0 && (
            <div className="flex items-center gap-1.5 text-amber-800 font-medium">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>{lowStockCountTotal} product(s) flagged for replenishment</span>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <div className="p-2 bg-red-100 rounded-full">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Product</h3>
                <p className="text-xs text-slate-500">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600">
              Are you sure you want to permanently remove <strong className="text-slate-900">{deleteConfirmProduct.name}</strong> (ID: {deleteConfirmProduct.id}) from the warehouse system?
            </p>

            <div className="bg-slate-50 p-3 rounded-md text-xs text-slate-600 space-y-1">
              <div><strong>Current Stock:</strong> {deleteConfirmProduct.quantity} {deleteConfirmProduct.unit}</div>
              <div><strong>Location:</strong> {deleteConfirmProduct.locationCode}</div>
              <div><strong>Supplier:</strong> {deleteConfirmProduct.supplierName}</div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmProduct(null)}
                className="px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteProduct(deleteConfirmProduct.id);
                  setDeleteConfirmProduct(null);
                }}
                className="px-3.5 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-md shadow-xs transition-colors cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
