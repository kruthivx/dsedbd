import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Plus, 
  CheckCircle2, 
  Truck, 
  Clock, 
  AlertCircle, 
  X,
  PackageCheck,
  Calendar,
  Layers
} from 'lucide-react';

export default function PurchaseOrdersView({
  purchaseOrders = [],
  suppliers = [],
  products = [],
  locations = [],
  onCreatePO,
  onReceivePO
}) {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [receivingId, setReceivingId] = useState(null);
  const [filterStatus, setFilterStatus] = useState('ALL');

  // Form state for creating PO
  const [poForm, setPoForm] = useState({
    supplierId: suppliers[0]?.id || '',
    destinationLocationId: locations[0]?.id || '',
    notes: 'Standard stock replenishment',
    items: [
      { productId: products[0]?.id || '', quantity: 50, unitPrice: products[0]?.price ? (products[0].price * 0.75).toFixed(2) : '15.00' }
    ]
  });

  const handleAddItemRow = () => {
    setPoForm(prev => ({
      ...prev,
      items: [
        ...prev.items,
        { productId: products[0]?.id || '', quantity: 50, unitPrice: '15.00' }
      ]
    }));
  };

  const handleRemoveItemRow = (index) => {
    setPoForm(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
  };

  const handleItemChange = (index, field, value) => {
    setPoForm(prev => {
      const updated = [...prev.items];
      updated[index] = { ...updated[index], [field]: value };
      if (field === 'productId') {
        const prod = products.find(p => p.id === value);
        if (prod) {
          updated[index].unitPrice = (prod.price * 0.75).toFixed(2);
        }
      }
      return { ...prev, items: updated };
    });
  };

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    if (!poForm.items || poForm.items.length === 0) return;
    await onCreatePO(poForm);
    setShowCreateModal(false);
  };

  const handleReceiveGoods = async (poId) => {
    try {
      setReceivingId(poId);
      await onReceivePO(poId);
    } finally {
      setReceivingId(null);
    }
  };

  const filteredOrders = filterStatus === 'ALL' 
    ? purchaseOrders 
    : purchaseOrders.filter(p => p.status === filterStatus);

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-slate-900 text-white rounded-md">
                <ShoppingCart className="w-5 h-5 text-amber-400" />
              </span>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Purchase Orders &amp; Inbound Goods Intake
              </h1>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Issue replenishment purchase orders to contracted suppliers and receive incoming inventory straight into warehouse bins.
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Purchase Order</span>
          </button>
        </div>

        {/* PO Metrics */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-100">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="text-[11px] font-medium text-slate-500">Active Inbound Orders</div>
            <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
              {purchaseOrders.filter(p => p.status === 'PENDING' || p.status === 'IN_TRANSIT').length}
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="text-[11px] font-medium text-slate-500">In Transit Deliveries</div>
            <div className="text-lg font-bold text-amber-700 font-mono tabular-nums mt-0.5">
              {purchaseOrders.filter(p => p.status === 'IN_TRANSIT').length}
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="text-[11px] font-medium text-slate-500">Received Goods (30d)</div>
            <div className="text-lg font-bold text-emerald-700 font-mono tabular-nums mt-0.5">
              {purchaseOrders.filter(p => p.status === 'RECEIVED').length}
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="text-[11px] font-medium text-slate-500">Committed Value</div>
            <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
              ${purchaseOrders.reduce((sum, p) => sum + p.totalAmount, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>
      </div>

      {/* Orders Filter Tabs */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center gap-1 overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Orders' },
            { id: 'PENDING', label: 'Pending Supplier Confirmation' },
            { id: 'IN_TRANSIT', label: 'In Transit / Dock Enroute' },
            { id: 'RECEIVED', label: 'Received into Warehouse' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                filterStatus === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* PO Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th className="py-3 px-4">PO Number</th>
                <th className="py-3 px-4">Supplier</th>
                <th className="py-3 px-4">Order Items</th>
                <th className="py-3 px-4 text-right">Total Amount</th>
                <th className="py-3 px-4">Destination Bay</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Expected Date</th>
                <th className="py-3 px-4 text-right">Intake Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <p className="text-sm font-medium text-slate-600">No purchase orders found</p>
                  </td>
                </tr>
              ) : (
                filteredOrders.map((po) => {
                  const isReceived = po.status === 'RECEIVED';
                  const isInTransit = po.status === 'IN_TRANSIT';

                  return (
                    <tr key={po.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        {po.orderNumber}
                      </td>

                      <td className="py-3 px-4 font-medium text-slate-800">
                        {po.supplierName}
                      </td>

                      <td className="py-3 px-4">
                        <div className="space-y-0.5">
                          {po.items.map((it, idx) => (
                            <div key={idx} className="text-slate-700">
                              <span className="font-semibold">{it.quantity}x</span> {it.productName}
                              <span className="text-[11px] text-slate-400 font-mono ml-1">(@ ${it.unitPrice.toFixed(2)})</span>
                            </div>
                          ))}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-slate-900">
                        ${po.totalAmount.toFixed(2)}
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-700">
                        <span className="bg-slate-100 px-2 py-0.5 rounded">
                          {po.destinationLocationCode}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {isReceived ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>RECEIVED</span>
                          </span>
                        ) : isInTransit ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            <Truck className="w-3 h-3 text-amber-600" />
                            <span>IN TRANSIT</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                            <Clock className="w-3 h-3 text-slate-500" />
                            <span>PENDING</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-600">
                        {new Date(po.expectedDeliveryDate).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-4 text-right">
                        {isReceived ? (
                          <span className="text-[11px] text-slate-400 font-medium">
                            Stock Added ✓
                          </span>
                        ) : (
                          <button
                            onClick={() => handleReceiveGoods(po.id)}
                            disabled={receivingId === po.id}
                            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded shadow-xs cursor-pointer disabled:opacity-50"
                          >
                            <PackageCheck className="w-3.5 h-3.5 text-amber-400" />
                            <span>{receivingId === po.id ? 'Processing...' : 'Receive Goods'}</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Purchase Order Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-xl w-full p-6 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Issue Replenishment Purchase Order
                </h2>
                <p className="text-xs text-slate-500">
                  Select supplier, items, expected quantities, and destination receiving dock.
                </p>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Select Supplier
                  </label>
                  <select
                    value={poForm.supplierId}
                    onChange={(e) => setPoForm({ ...poForm, supplierId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
                  >
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.leadTimeDays}d lead)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Destination Put-Away Location
                  </label>
                  <select
                    value={poForm.destinationLocationId}
                    onChange={(e) => setPoForm({ ...poForm, destinationLocationId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white font-mono focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
                  >
                    {locations.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.code} · {loc.zone}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Items Line Items */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-semibold text-slate-800">Order Items</label>
                  <button
                    type="button"
                    onClick={handleAddItemRow}
                    className="text-xs text-slate-900 font-medium underline cursor-pointer"
                  >
                    + Add Another Item
                  </button>
                </div>

                <div className="space-y-2">
                  {poForm.items.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 border border-slate-200 rounded-md">
                      <select
                        value={item.productId}
                        onChange={(e) => handleItemChange(idx, 'productId', e.target.value)}
                        className="flex-1 px-2 py-1.5 bg-white border border-slate-200 rounded text-xs cursor-pointer"
                      >
                        {products.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} ({p.sku})
                          </option>
                        ))}
                      </select>

                      <input
                        type="number"
                        min="1"
                        placeholder="Qty"
                        value={item.quantity}
                        onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                        className="w-20 px-2 py-1.5 bg-white border border-slate-200 rounded text-xs font-mono tabular-nums"
                      />

                      <div className="relative w-24">
                        <span className="absolute left-2 top-1.5 text-slate-400">$</span>
                        <input
                          type="number"
                          step="0.01"
                          placeholder="Cost"
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(idx, 'unitPrice', e.target.value)}
                          className="w-full pl-5 pr-2 py-1.5 bg-white border border-slate-200 rounded text-xs font-mono tabular-nums"
                        />
                      </div>

                      {poForm.items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveItemRow(idx)}
                          className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Order Notes / Delivery Instructions
                </label>
                <input
                  type="text"
                  value={poForm.notes}
                  onChange={(e) => setPoForm({ ...poForm, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs cursor-pointer"
                >
                  Submit Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
