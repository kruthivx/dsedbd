import React, { useState, useMemo } from 'react';
import { 
  ArrowRightLeft, 
  ArrowDownRight, 
  ArrowUpRight, 
  Plus, 
  Search, 
  Filter, 
  Download,
  Calendar,
  Layers,
  MapPin,
  CheckCircle2,
  Clock
} from 'lucide-react';

export default function StockMovementsView({
  movements = [],
  products = [],
  onOpenMovementModal
}) {
  const [filterType, setFilterType] = useState('ALL'); // 'ALL' | 'INBOUND' | 'INTERNAL_TRANSFER' | 'OUTBOUND' | 'ADJUSTMENT'
  const [searchTerm, setSearchTerm] = useState('');

  const filteredMovements = useMemo(() => {
    return movements.filter(m => {
      const matchesType = filterType === 'ALL' || m.type === filterType;
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch = !q || 
        m.id.toLowerCase().includes(q) ||
        m.productName.toLowerCase().includes(q) ||
        m.sku.toLowerCase().includes(q) ||
        m.referenceNumber.toLowerCase().includes(q) ||
        (m.fromLocation && m.fromLocation.toLowerCase().includes(q)) ||
        (m.toLocation && m.toLocation.toLowerCase().includes(q)) ||
        (m.operator && m.operator.toLowerCase().includes(q));

      return matchesType && matchesSearch;
    });
  }, [movements, filterType, searchTerm]);

  // Aggregate metrics
  const inboundCount = movements.filter(m => m.type === 'INBOUND').reduce((sum, m) => sum + Math.abs(m.quantity), 0);
  const transferCount = movements.filter(m => m.type === 'INTERNAL_TRANSFER').reduce((sum, m) => sum + Math.abs(m.quantity), 0);
  const outboundCount = movements.filter(m => m.type === 'OUTBOUND').reduce((sum, m) => sum + Math.abs(m.quantity), 0);

  const exportMovementsCSV = () => {
    const headers = ['Movement ID,Timestamp,Type,Product ID,Product Name,Quantity,From,To,Reference,Operator,Reason'];
    const rows = filteredMovements.map(m => 
      `"${m.id}","${m.timestamp}","${m.type}","${m.productId}","${m.productName}","${m.quantity}","${m.fromLocation || ''}","${m.toLocation || ''}","${m.referenceNumber}","${m.operator}","${m.reason || ''}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `warehouse_stock_movements_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Top Banner & Stats */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-slate-900 text-white rounded-md">
                <ArrowRightLeft className="w-5 h-5 text-amber-400" />
              </span>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Stock Movements &amp; Relocation Audit
              </h1>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              End-to-end custody audit trail tracking products entering, relocating across aisles, and leaving for dispatch.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportMovementsCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Export Log</span>
            </button>

            <button
              onClick={onOpenMovementModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Movement</span>
            </button>
          </div>
        </div>

        {/* 3 Movement Pillars */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-100">
          {/* Entering */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-semibold">
                <ArrowDownRight className="w-4 h-4 text-emerald-600" />
                <span>Entering (Inbound)</span>
              </div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                +{inboundCount.toLocaleString()} units
              </div>
              <div className="text-[10px] text-slate-400">Goods receipts &amp; intake</div>
            </div>
          </div>

          {/* Moving within */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-slate-800 text-xs font-semibold">
                <ArrowRightLeft className="w-4 h-4 text-slate-600" />
                <span>Moving Within (Transfers)</span>
              </div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                {transferCount.toLocaleString()} units
              </div>
              <div className="text-[10px] text-slate-400">Bay &amp; rack relocations</div>
            </div>
          </div>

          {/* Leaving */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-amber-800 text-xs font-semibold">
                <ArrowUpRight className="w-4 h-4 text-amber-600" />
                <span>Leaving (Dispatches)</span>
              </div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-0.5">
                -{outboundCount.toLocaleString()} units
              </div>
              <div className="text-[10px] text-slate-400">Orders fulfilled &amp; shipped</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Table Card */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-2xs overflow-hidden">
        {/* Controls Toolbar */}
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Segmented Control for Movement Type */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-full sm:w-auto overflow-x-auto">
            {[
              { id: 'ALL', label: 'All Movements' },
              { id: 'INBOUND', label: 'Entering (Inbound)' },
              { id: 'INTERNAL_TRANSFER', label: 'Moving Within' },
              { id: 'OUTBOUND', label: 'Leaving (Outbound)' },
              { id: 'ADJUSTMENT', label: 'Adjustments' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterType(tab.id)}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  filterType === tab.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search reference, product, location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900"
            />
          </div>
        </div>

        {/* Movements Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th className="py-3 px-4">Movement ID</th>
                <th className="py-3 px-4">Classification</th>
                <th className="py-3 px-4">Product &amp; SKU</th>
                <th className="py-3 px-4 text-right">Quantity</th>
                <th className="py-3 px-4">Routing Path</th>
                <th className="py-3 px-4">Reference</th>
                <th className="py-3 px-4">Operator / Reason</th>
                <th className="py-3 px-4 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredMovements.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <p className="text-sm font-medium text-slate-600">No stock movements recorded</p>
                    <button
                      onClick={onOpenMovementModal}
                      className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-md cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Record First Movement</span>
                    </button>
                  </td>
                </tr>
              ) : (
                filteredMovements.map((m) => {
                  const isInbound = m.type === 'INBOUND';
                  const isOutbound = m.type === 'OUTBOUND';
                  const isTransfer = m.type === 'INTERNAL_TRANSFER';

                  return (
                    <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Movement ID */}
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">
                        {m.id}
                      </td>

                      {/* Classification */}
                      <td className="py-3 px-4">
                        {isInbound && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <ArrowDownRight className="w-3 h-3 text-emerald-600" />
                            <span>ENTERING</span>
                          </span>
                        )}
                        {isTransfer && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            <ArrowRightLeft className="w-3 h-3 text-slate-600" />
                            <span>MOVING WITHIN</span>
                          </span>
                        )}
                        {isOutbound && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            <ArrowUpRight className="w-3 h-3 text-amber-600" />
                            <span>LEAVING</span>
                          </span>
                        )}
                        {m.type === 'ADJUSTMENT' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                            <span>ADJUSTMENT</span>
                          </span>
                        )}
                      </td>

                      {/* Product */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{m.productName}</div>
                        <div className="text-[11px] font-mono text-slate-400">{m.sku}</div>
                      </td>

                      {/* Quantity */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-sm">
                        <span className={isInbound ? 'text-emerald-700' : isOutbound ? 'text-amber-700' : 'text-slate-900'}>
                          {m.quantity > 0 ? `+${m.quantity}` : m.quantity}
                        </span>
                      </td>

                      {/* Routing Path */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-700">
                          <span className="bg-slate-100 px-1.5 py-0.5 rounded max-w-[120px] truncate" title={m.fromLocation}>
                            {m.fromLocation || 'Dock'}
                          </span>
                          <span className="text-slate-400">→</span>
                          <span className="bg-slate-100 px-1.5 py-0.5 rounded font-bold max-w-[120px] truncate" title={m.toLocation}>
                            {m.toLocation || 'Bin'}
                          </span>
                        </div>
                      </td>

                      {/* Reference */}
                      <td className="py-3 px-4 font-mono text-slate-600">
                        {m.referenceNumber}
                      </td>

                      {/* Operator & Reason */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">{m.operator}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-xs">{m.reason}</div>
                      </td>

                      {/* Timestamp */}
                      <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        <span className="block text-[10px] text-slate-400">
                          {new Date(m.timestamp).toISOString().slice(0, 10)}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
