import React, { useState } from 'react';
import { 
  Layers, 
  MapPin, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  X,
  Package,
  HardDrive
} from 'lucide-react';

export default function WarehouseLocationsView({
  locations = [],
  products = [],
  onCreateLocation
}) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newLoc, setNewLoc] = useState({
    code: '',
    zone: 'Zone A (Bulk Pallet Rack)',
    aisle: 'A01',
    rack: 'R01',
    shelf: 'S01',
    type: 'PALLET_RACK',
    maxCapacity: 1000
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newLoc.code.trim()) return;
    await onCreateLocation(newLoc);
    setShowAddModal(false);
    setNewLoc({
      code: '',
      zone: 'Zone A (Bulk Pallet Rack)',
      aisle: 'A01',
      rack: 'R01',
      shelf: 'S01',
      type: 'PALLET_RACK',
      maxCapacity: 1000
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-slate-900 text-white rounded-md">
                <Layers className="w-5 h-5 text-amber-400" />
              </span>
              <h1 className="text-xl font-bold tracking-tight text-slate-900">
                Warehouse Locations &amp; Bay Capacity
              </h1>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Topological warehouse layout mapping aisles, high bays, cold storage, and receiving docks with live volumetric occupancy.
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Location Bin</span>
          </button>
        </div>
      </div>

      {/* Grid of Locations */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {locations.map((loc) => {
          const locProducts = products.filter(p => p.locationCode === loc.code || p.locationId === loc.id);
          const currentUnits = locProducts.reduce((sum, p) => sum + p.quantity, 0);
          const occupancyRate = Math.min(100, Math.round((currentUnits / loc.maxCapacity) * 100));
          const isNearlyFull = occupancyRate >= 85;

          return (
            <div 
              key={loc.id}
              className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-2 bg-slate-100 rounded-md font-mono font-bold text-slate-900 text-sm">
                    {loc.code}
                  </span>
                  <div>
                    <div className="font-semibold text-slate-900 text-xs">
                      {loc.zone}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Aisle {loc.aisle} · Rack {loc.rack} · Shelf {loc.shelf}
                    </div>
                  </div>
                </div>

                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded font-mono ${
                  isNearlyFull ? 'bg-amber-100 text-amber-800' : 'bg-emerald-50 text-emerald-700'
                }`}>
                  {occupancyRate}% Full
                </span>
              </div>

              {/* Progress Bar */}
              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                  <span>Occupancy</span>
                  <span className="font-mono tabular-nums">
                    <strong>{currentUnits.toLocaleString()}</strong> / {loc.maxCapacity.toLocaleString()} units
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-300 ${
                      occupancyRate >= 90 ? 'bg-red-500' : occupancyRate >= 75 ? 'bg-amber-500' : 'bg-slate-900'
                    }`}
                    style={{ width: `${occupancyRate}%` }}
                  />
                </div>
              </div>

              {/* Stored Products List */}
              <div className="pt-2 border-t border-slate-100">
                <div className="text-[11px] font-medium text-slate-500 mb-1.5 flex items-center justify-between">
                  <span>Assigned Products ({locProducts.length})</span>
                  <HardDrive className="w-3 h-3 text-slate-400" />
                </div>
                {locProducts.length === 0 ? (
                  <div className="text-[11px] text-slate-400 italic py-1">
                    Empty bin available for put-away
                  </div>
                ) : (
                  <div className="space-y-1">
                    {locProducts.slice(0, 3).map((p) => (
                      <div key={p.id} className="flex items-center justify-between text-xs text-slate-700">
                        <span className="truncate max-w-[180px]">{p.name}</span>
                        <span className="font-mono tabular-nums font-semibold text-slate-900 shrink-0">
                          {p.quantity} {p.unit}
                        </span>
                      </div>
                    ))}
                    {locProducts.length > 3 && (
                      <div className="text-[10px] text-slate-400">
                        + {locProducts.length - 3} more products
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Location Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">
                Register Warehouse Location Bin
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Location Code (e.g. C-02-04)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. B-04-12"
                  value={newLoc.code}
                  onChange={(e) => setNewLoc({ ...newLoc, code: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 font-mono uppercase border border-slate-200 rounded-md focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Warehouse Zone
                </label>
                <select
                  value={newLoc.zone}
                  onChange={(e) => setNewLoc({ ...newLoc, zone: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
                >
                  <option value="Zone A (Bulk Pallet Rack)">Zone A (Bulk Pallet Rack)</option>
                  <option value="Zone B (High Bay Electronics)">Zone B (High Bay Electronics)</option>
                  <option value="Zone C (Temp Controlled Bay)">Zone C (Temp Controlled Bay)</option>
                  <option value="Zone D (Small Parts Binning)">Zone D (Small Parts Binning)</option>
                  <option value="Dock 2 (Shipping & Dispatch)">Dock 2 (Shipping &amp; Dispatch)</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Aisle</label>
                  <input
                    type="text"
                    value={newLoc.aisle}
                    onChange={(e) => setNewLoc({ ...newLoc, aisle: e.target.value })}
                    className="w-full px-2 py-1.5 border border-slate-200 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Rack</label>
                  <input
                    type="text"
                    value={newLoc.rack}
                    onChange={(e) => setNewLoc({ ...newLoc, rack: e.target.value })}
                    className="w-full px-2 py-1.5 border border-slate-200 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Shelf</label>
                  <input
                    type="text"
                    value={newLoc.shelf}
                    onChange={(e) => setNewLoc({ ...newLoc, shelf: e.target.value })}
                    className="w-full px-2 py-1.5 border border-slate-200 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Max Unit Capacity
                </label>
                <input
                  type="number"
                  min="50"
                  value={newLoc.maxCapacity}
                  onChange={(e) => setNewLoc({ ...newLoc, maxCapacity: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md font-mono tabular-nums"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs cursor-pointer"
                >
                  Create Bin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
