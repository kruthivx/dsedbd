import React from 'react';
import { 
  Package, 
  Plus, 
  AlertTriangle, 
  LogOut, 
  User 
} from 'lucide-react';

export default function Navbar({
  activeTab,
  setActiveTab,
  onAddProduct,
  onQuickMove,
  lowStockCount,
  onRefresh,
  loading,
  currentUser,
  onLogout
}) {
  const navItems = [
    { id: 'products', label: 'Inventory & Products' },
    { id: 'forecast', label: 'Demand Forecasting' },
    { id: 'movements', label: 'Stock Movements' },
    { id: 'purchase-orders', label: 'Purchase Orders' },
    { id: 'locations', label: 'Locations & Bays' },
    { id: 'suppliers', label: 'Suppliers' }
  ];

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-6 px-6 py-3 bg-white border-b border-slate-200">
      {/* Zone 1: Single Brand Wordmark ("Warehouse System") */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-slate-900 text-white font-bold text-sm tracking-wide shadow-xs">
          <Package className="w-4 h-4 text-amber-400" />
        </div>
        <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
          Warehouse System
        </span>
      </div>

      {/* Zone 2: Clean Single-line Navigation Links */}
      <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative py-1 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isActive ? 'text-slate-900 font-semibold' : 'text-slate-600'
              }`}
            >
              {item.label}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-slate-900 rounded-full" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Primary Action & Tools Zone */}
      <div className="flex items-center gap-2.5 shrink-0">
        {/* Low Stock Warning Pill */}
        {lowStockCount > 0 && (
          <button
            onClick={() => setActiveTab('products')}
            title={`${lowStockCount} items below safety limit`}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-amber-900 bg-amber-50 border border-amber-200 rounded-md hover:bg-amber-100 transition-colors cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className="tabular-nums font-bold">{lowStockCount}</span> Low Stock
          </button>
        )}



        {/* Quick Log Movement */}
        <button
          onClick={onQuickMove}
          className="hidden md:inline-flex px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
        >
          Log Move
        </button>

        {/* Add Product Button */}
        <button
          onClick={onAddProduct}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Product</span>
        </button>

        {/* User Account / Logout Action */}
        {currentUser && (
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-semibold text-slate-900 leading-tight">
                {currentUser.name}
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {currentUser.role}
              </span>
            </div>
            <button
              onClick={onLogout}
              title="Sign Out to Login Page"
              className="flex items-center gap-1 px-2 py-1 text-xs text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
