import React, { useState, useEffect } from 'react';
import { X, Plus, AlertCircle } from 'lucide-react';

export default function ProductFormModal({
  isOpen,
  onClose,
  onSubmit,
  initialData = null,
  categories = [],
  suppliers = [],
  locations = [],
  onAddNewCategory
}) {
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    category: categories[0] || 'General',
    price: '',
    quantity: '',
    unit: 'pcs',
    supplierId: suppliers[0]?.id || '',
    locationId: locations[0]?.id || '',
    lowStockThreshold: 25,
    description: ''
  });

  const [newCatInput, setNewCatInput] = useState('');
  const [showNewCatInput, setShowNewCatInput] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        sku: initialData.sku || '',
        category: initialData.category || categories[0] || '',
        price: initialData.price !== undefined ? initialData.price : '',
        quantity: initialData.quantity !== undefined ? initialData.quantity : '',
        unit: initialData.unit || 'pcs',
        supplierId: initialData.supplierId || suppliers[0]?.id || '',
        locationId: initialData.locationId || locations[0]?.id || '',
        lowStockThreshold: initialData.lowStockThreshold !== undefined ? initialData.lowStockThreshold : 25,
        description: initialData.description || ''
      });
    } else {
      setFormData({
        name: '',
        sku: `SKU-${Math.floor(100000 + Math.random() * 900000)}`,
        category: categories[0] || 'Electronics',
        price: '',
        quantity: '',
        unit: 'pcs',
        supplierId: suppliers[0]?.id || '',
        locationId: locations[0]?.id || '',
        lowStockThreshold: 25,
        description: ''
      });
    }
    setError('');
  }, [initialData, isOpen, categories, suppliers, locations]);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!formData.name.trim()) {
      setError('Product Name is required.');
      return;
    }

    if (formData.price === '' || isNaN(Number(formData.price)) || Number(formData.price) < 0) {
      setError('Please provide a valid price (greater than or equal to 0).');
      return;
    }

    if (formData.quantity === '' || isNaN(Number(formData.quantity)) || Number(formData.quantity) < 0) {
      setError('Please provide a valid quantity (greater than or equal to 0).');
      return;
    }

    try {
      setSubmitting(true);
      await onSubmit({
        ...formData,
        price: Number(formData.price),
        quantity: Number(formData.quantity),
        lowStockThreshold: Number(formData.lowStockThreshold) || 20
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to save product');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddCategory = () => {
    if (newCatInput.trim()) {
      onAddNewCategory(newCatInput.trim());
      setFormData(prev => ({ ...prev, category: newCatInput.trim() }));
      setNewCatInput('');
      setShowNewCatInput(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl border border-slate-200 max-w-xl w-full p-6 space-y-4 my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {initialData ? 'Edit Product Details' : 'Add New Warehouse Product'}
            </h2>
            <p className="text-xs text-slate-500">
              Register stock specifications, supplier link, and assigned warehouse storage bin.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 text-red-800 rounded-md text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Product Name */}
          <div>
            <label className="block font-medium text-slate-700 mb-1">
              Product Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Wireless Bluetooth Headphones, Cotton T-Shirt, Water Bottle..."
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900"
            />
          </div>

          {/* SKU & Category Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                SKU / Barcode Identifier
              </label>
              <input
                type="text"
                placeholder="e.g. FST-TIT-M12"
                value={formData.sku}
                onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                className="w-full px-3 py-2 font-mono uppercase border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-medium text-slate-700">Category</label>
                <button
                  type="button"
                  onClick={() => setShowNewCatInput(!showNewCatInput)}
                  className="text-[11px] text-slate-500 hover:text-slate-900 underline cursor-pointer"
                >
                  {showNewCatInput ? 'Select Existing' : '+ New Category'}
                </button>
              </div>

              {showNewCatInput ? (
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    placeholder="New category..."
                    value={newCatInput}
                    onChange={(e) => setNewCatInput(e.target.value)}
                    className="w-full px-2 py-1.5 border border-slate-200 rounded-md text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddCategory}
                    className="px-2 py-1.5 bg-slate-900 text-white rounded-md text-xs font-medium cursor-pointer"
                  >
                    Add
                  </button>
                </div>
              ) : (
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          {/* Price, Quantity & Unit Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Unit Price ($) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-slate-400 font-mono">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  placeholder="0.00"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full pl-7 pr-3 py-2 font-mono tabular-nums border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Quantity <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                required
                placeholder="100"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                className="w-full px-3 py-2 font-mono tabular-nums border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Unit of Measure
              </label>
              <select
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
              >
                <option value="pcs">Pieces (pcs)</option>
                <option value="units">Units</option>
                <option value="boxes">Boxes</option>
                <option value="pairs">Pairs</option>
                <option value="bars">Bars</option>
                <option value="rolls">Rolls</option>
                <option value="kg">Kilograms (kg)</option>
                <option value="liters">Liters</option>
              </select>
            </div>
          </div>

          {/* Low Stock Warning Threshold */}
          <div className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-md">
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-amber-900 flex items-center gap-1.5">
                <span>Low-Stock Warning Threshold</span>
              </label>
              <span className="text-[11px] text-amber-700">
                Warning triggers when quantity &le; threshold
              </span>
            </div>
            <input
              type="number"
              min="1"
              value={formData.lowStockThreshold}
              onChange={(e) => setFormData({ ...formData, lowStockThreshold: e.target.value })}
              className="w-full px-3 py-1.5 font-mono tabular-nums bg-white border border-amber-300 rounded-md focus:outline-hidden focus:ring-1 focus:ring-amber-500"
            />
          </div>

          {/* Supplier & Location Assignment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Supplier Link
              </label>
              <select
                value={formData.supplierId}
                onChange={(e) => setFormData({ ...formData, supplierId: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 cursor-pointer"
              >
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code}) - {s.leadTimeDays}d lead
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Warehouse Location Bin
              </label>
              <select
                value={formData.locationId}
                onChange={(e) => setFormData({ ...formData, locationId: e.target.value })}
                className="w-full px-3 py-2 border border-slate-200 rounded-md bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 font-mono cursor-pointer"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.code} · {loc.zone}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block font-medium text-slate-700 mb-1">
              Technical Description / Storage Notes
            </label>
            <textarea
              rows="2"
              placeholder="Material grade, handling precautions, temperature requirements..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 border border-slate-200 rounded-md focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-slate-900 resize-none"
            />
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            >
              {submitting ? 'Saving...' : initialData ? 'Update Product' : 'Add Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
