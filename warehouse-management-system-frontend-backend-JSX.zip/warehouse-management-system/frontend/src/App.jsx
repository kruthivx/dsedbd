/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import RawNavbar from './components/Navbar.jsx';
import RawSidebar from './components/Sidebar.jsx';
import RawProductsTable from './components/ProductsTable.jsx';
import RawProductFormModal from './components/ProductFormModal.jsx';
import RawDemandForecastView from './components/DemandForecastView.jsx';
import RawStockMovementsView from './components/StockMovementsView.jsx';
import RawStockMovementModal from './components/StockMovementModal.jsx';
import RawPurchaseOrdersView from './components/PurchaseOrdersView.jsx';
import RawWarehouseLocationsView from './components/WarehouseLocationsView.jsx';
import RawSuppliersView from './components/SuppliersView.jsx';
import RawOverviewDashboard from './components/OverviewDashboard.jsx';
import RawAuthPage from './components/AuthPage.jsx';
import { api } from './services/api.js';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

const Navbar = RawNavbar as React.ComponentType<any>;
const Sidebar = RawSidebar as React.ComponentType<any>;
const ProductsTable = RawProductsTable as React.ComponentType<any>;
const ProductFormModal = RawProductFormModal as React.ComponentType<any>;
const DemandForecastView = RawDemandForecastView as React.ComponentType<any>;
const StockMovementsView = RawStockMovementsView as React.ComponentType<any>;
const StockMovementModal = RawStockMovementModal as React.ComponentType<any>;
const PurchaseOrdersView = RawPurchaseOrdersView as React.ComponentType<any>;
const WarehouseLocationsView = RawWarehouseLocationsView as React.ComponentType<any>;
const SuppliersView = RawSuppliersView as React.ComponentType<any>;
const OverviewDashboard = RawOverviewDashboard as React.ComponentType<any>;
const AuthPage = RawAuthPage as React.ComponentType<any>;

export default function App() {
  const [activeTab, setActiveTab] = useState('products');
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [locations, setLocations] = useState([]);
  const [movements, setMovements] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);

  // Authentication State: null by default so user sees the Sign In & Login navigation page FIRST!
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const stored = localStorage.getItem('warehouse_user');
      if (stored) return JSON.parse(stored);
    } catch {}
    return null;
  });

  // Modals state
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [movementModalOpen, setMovementModalOpen] = useState(false);
  const [movementPreselectedProduct, setMovementPreselectedProduct] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Fetch all initial data from REST API
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const [prodRes, catRes, supRes, locRes, movRes, poRes, statsRes] = await Promise.all([
        api.getProducts(),
        api.getCategories(),
        api.getSuppliers(),
        api.getLocations(),
        api.getMovements(),
        api.getPurchaseOrders(),
        api.getStats()
      ]);

      if (prodRes.success) setProducts(prodRes.products || []);
      if (catRes.success) setCategories(catRes.categories || []);
      if (supRes.success) setSuppliers(supRes.suppliers || []);
      if (locRes.success) setLocations(locRes.locations || []);
      if (movRes.success) setMovements(movRes.movements || []);
      if (poRes.success) setPurchaseOrders(poRes.purchaseOrders || []);
      if (statsRes.success) setStats(statsRes.stats || null);
    } catch (err) {
      console.error('Failed to fetch data from warehouse REST API:', err);
      showToast('Error syncing with backend REST API: ' + (err?.message || 'Network error'), 'error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadData();
    }
  }, [currentUser, loadData]);

  // Auth Handlers
  const handleAuthSuccess = (user) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('warehouse_user', JSON.stringify(user));
    } catch {}
    showToast(`Welcome, ${user.name}! Navigating to Warehouse Home.`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem('warehouse_user');
    } catch {}
    showToast('Signed out. Redirecting to login.');
  };

  // Product CRUD
  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod) => {
    setEditingProduct(prod);
    setProductModalOpen(true);
  };

  const handleSaveProduct = async (formData) => {
    if (editingProduct) {
      const res = await api.updateProduct(editingProduct.id, formData);
      if (res.success) {
        showToast(`Product "${res.product.name}" updated successfully.`);
        loadData();
      }
    } else {
      const res = await api.createProduct(formData);
      if (res.success) {
        showToast(`Product "${res.product.name}" registered with ID ${res.product.id}.`);
        loadData();
      }
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      const res = await api.deleteProduct(id);
      if (res.success) {
        showToast(`Product ${id} deleted.`);
        loadData();
      }
    } catch (err) {
      showToast(err?.message || 'Failed to delete product', 'error');
    }
  };

  // Stock Movement handlers
  const handleOpenMovementModal = (product = null) => {
    setMovementPreselectedProduct(product);
    setMovementModalOpen(true);
  };

  const handleSaveMovement = async (movementData) => {
    const res = await api.createMovement({
      ...movementData,
      operator: currentUser?.name || 'Warehouse Staff'
    });
    if (res.success) {
      showToast(`Stock movement recorded: ${movementData.type} for ${movementData.quantity} units.`);
      loadData();
    }
  };

  // Purchase Order handlers
  const handleCreatePO = async (poData) => {
    try {
      const res = await api.createPurchaseOrder(poData);
      if (res.success) {
        showToast(`Purchase order ${res.purchaseOrder.orderNumber} issued to ${res.purchaseOrder.supplierName}.`);
        loadData();
      }
    } catch (err) {
      showToast(err?.message || 'Failed to create PO', 'error');
    }
  };

  const handleReceivePO = async (poId) => {
    try {
      const res = await api.receivePurchaseOrder(poId);
      if (res.success) {
        showToast(`Goods received from PO ${poId}. Inventory quantities automatically updated!`);
        loadData();
      }
    } catch (err) {
      showToast(err?.message || 'Failed to receive goods', 'error');
    }
  };

  const handleCreatePOForProduct = async (productId, suggestedQty = 50) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    
    try {
      const poData = {
        supplierId: prod.supplierId,
        destinationLocationId: prod.locationId,
        notes: `Urgent demand replenishment for SKU ${prod.sku}`,
        items: [
          {
            productId: prod.id,
            quantity: suggestedQty || 50,
            unitPrice: Number((prod.price * 0.75).toFixed(2))
          }
        ]
      };
      const res = await api.createPurchaseOrder(poData);
      if (res.success) {
        showToast(`Replenishment PO ${res.purchaseOrder.orderNumber} generated for ${prod.name}!`);
        setActiveTab('purchase-orders');
        loadData();
      }
    } catch (err) {
      showToast(err?.message || 'Failed to create replenishment PO', 'error');
    }
  };

  // Category and Location additions
  const handleAddNewCategory = async (catName) => {
    const res = await api.createCategory(catName);
    if (res.success) {
      setCategories(res.categories);
      showToast(`Category "${catName}" added.`);
    }
  };

  const handleCreateLocation = async (locData) => {
    const res = await api.createLocation(locData);
    if (res.success) {
      showToast(`Location bin ${res.location.code} created in ${res.location.zone}.`);
      loadData();
    }
  };

  const handleCreateSupplier = async (supData) => {
    const res = await api.createSupplier(supData);
    if (res.success) {
      showToast(`Supplier ${res.supplier.name} added to directory.`);
      loadData();
    }
  };

  const lowStockCount = products.filter(p => p.quantity <= p.lowStockThreshold).length;

  // FIRST PAGE: If user is not signed in, show Sign In / Login navigation page first!
  if (!currentUser) {
    return (
      <>
        {toast && (
          <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-3 bg-slate-900 text-white rounded-lg shadow-xl border border-slate-800 text-xs animate-in slide-in-from-bottom-2">
            {toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span>{toast.message}</span>
            <button 
              onClick={() => setToast(null)}
              className="ml-2 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        <AuthPage onLoginSuccess={handleAuthSuccess} />
      </>
    );
  }

  // MAIN HOME PAGE: Rendered only after user logs in
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-3 bg-slate-900 text-white rounded-lg shadow-xl border border-slate-800 text-xs animate-in slide-in-from-bottom-2">
          {toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          )}
          <span>{toast.message}</span>
          <button 
            onClick={() => setToast(null)}
            className="ml-2 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onAddProduct={handleOpenAddProduct}
        onQuickMove={() => handleOpenMovementModal(null)}
        lowStockCount={lowStockCount}
        onRefresh={loadData}
        loading={loading}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      <div className="flex flex-1">
        {/* Desktop Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          stats={stats}
        />

        {/* Main Content Viewport (Home Page) */}
        <main className="flex-1 p-4 md:p-6 max-w-7xl mx-auto w-full">
          {activeTab === 'overview' && (
            <OverviewDashboard
              stats={stats}
              products={products}
              movements={movements}
              locations={locations}
              purchaseOrders={purchaseOrders}
              onNavigateTab={setActiveTab}
              onAddProduct={handleOpenAddProduct}
              onQuickMove={() => handleOpenMovementModal(null)}
              onCreatePOForProduct={handleCreatePOForProduct}
            />
          )}

          {activeTab === 'products' && (
            <ProductsTable
              products={products}
              categories={categories}
              suppliers={suppliers}
              locations={locations}
              onAddProduct={handleOpenAddProduct}
              onEditProduct={handleOpenEditProduct}
              onDeleteProduct={handleDeleteProduct}
              onLogMovement={handleOpenMovementModal}
              loading={loading}
            />
          )}

          {activeTab === 'forecast' && (
            <DemandForecastView
              onCreatePOForProduct={handleCreatePOForProduct}
              onRefreshNeeded={loadData}
            />
          )}

          {activeTab === 'movements' && (
            <StockMovementsView
              movements={movements}
              products={products}
              onOpenMovementModal={() => handleOpenMovementModal(null)}
            />
          )}

          {activeTab === 'purchase-orders' && (
            <PurchaseOrdersView
              purchaseOrders={purchaseOrders}
              suppliers={suppliers}
              products={products}
              locations={locations}
              onCreatePO={handleCreatePO}
              onReceivePO={handleReceivePO}
            />
          )}

          {activeTab === 'locations' && (
            <WarehouseLocationsView
              locations={locations}
              products={products}
              onCreateLocation={handleCreateLocation}
            />
          )}

          {activeTab === 'suppliers' && (
            <SuppliersView
              suppliers={suppliers}
              products={products}
              onCreateSupplier={handleCreateSupplier}
            />
          )}
        </main>
      </div>

      {/* Product Form Modal (Add / Edit) */}
      <ProductFormModal
        isOpen={productModalOpen}
        onClose={() => setProductModalOpen(false)}
        onSubmit={handleSaveProduct}
        initialData={editingProduct}
        categories={categories}
        suppliers={suppliers}
        locations={locations}
        onAddNewCategory={handleAddNewCategory}
      />

      {/* Stock Movement Modal (Entering, Moving within, Leaving) */}
      <StockMovementModal
        isOpen={movementModalOpen}
        onClose={() => setMovementModalOpen(false)}
        onSubmit={handleSaveMovement}
        products={products}
        locations={locations}
        preselectedProduct={movementPreselectedProduct}
      />
    </div>
  );
}
