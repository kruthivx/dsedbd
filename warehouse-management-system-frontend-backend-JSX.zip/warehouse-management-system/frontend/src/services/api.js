/**
 * REST API client for Apex Warehouse Management System
 * Connects to backend REST endpoints with JSON payloads and error handling.
 */

const BASE_URL = '/api';

export const api = {
  // Products
  async getProducts(params = {}) {
    const query = new URLSearchParams();
    if (params.search) query.set('search', params.search);
    if (params.category && params.category !== 'ALL') query.set('category', params.category);
    if (params.supplier && params.supplier !== 'ALL') query.set('supplier', params.supplier);
    if (params.lowStockOnly) query.set('lowStockOnly', 'true');
    
    const res = await fetch(`${BASE_URL}/products?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch products');
    return res.json();
  },

  async getProduct(id) {
    const res = await fetch(`${BASE_URL}/products/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error('Product not found');
    return res.json();
  },

  async createProduct(data) {
    const res = await fetch(`${BASE_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Failed to create product');
    }
    return res.json();
  },

  async updateProduct(id, data) {
    const res = await fetch(`${BASE_URL}/products/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Failed to update product');
    }
    return res.json();
  },

  async deleteProduct(id) {
    const res = await fetch(`${BASE_URL}/products/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Failed to delete product');
    return res.json();
  },

  // Categories
  async getCategories() {
    const res = await fetch(`${BASE_URL}/categories`);
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  async createCategory(name) {
    const res = await fetch(`${BASE_URL}/categories`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    if (!res.ok) throw new Error('Failed to add category');
    return res.json();
  },

  // Suppliers
  async getSuppliers() {
    const res = await fetch(`${BASE_URL}/suppliers`);
    if (!res.ok) throw new Error('Failed to fetch suppliers');
    return res.json();
  },

  async createSupplier(data) {
    const res = await fetch(`${BASE_URL}/suppliers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create supplier');
    return res.json();
  },

  // Locations
  async getLocations() {
    const res = await fetch(`${BASE_URL}/locations`);
    if (!res.ok) throw new Error('Failed to fetch warehouse locations');
    return res.json();
  },

  async createLocation(data) {
    const res = await fetch(`${BASE_URL}/locations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create location');
    return res.json();
  },

  // Stock Movements (Inbound, Internal Transfer, Outbound, Adjustment)
  async getMovements(params = {}) {
    const query = new URLSearchParams();
    if (params.productId) query.set('productId', params.productId);
    if (params.type && params.type !== 'ALL') query.set('type', params.type);

    const res = await fetch(`${BASE_URL}/stock-movements?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch stock movements');
    return res.json();
  },

  async createMovement(data) {
    const res = await fetch(`${BASE_URL}/stock-movements`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Failed to log stock movement');
    }
    return res.json();
  },

  // Purchase Orders
  async getPurchaseOrders() {
    const res = await fetch(`${BASE_URL}/purchase-orders`);
    if (!res.ok) throw new Error('Failed to fetch purchase orders');
    return res.json();
  },

  async createPurchaseOrder(data) {
    const res = await fetch(`${BASE_URL}/purchase-orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to create purchase order');
    return res.json();
  },

  async receivePurchaseOrder(id) {
    const res = await fetch(`${BASE_URL}/purchase-orders/${encodeURIComponent(id)}/receive`, {
      method: 'POST'
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Failed to receive purchase order');
    }
    return res.json();
  },

  // Demand Forecast
  async getForecast(productId = null) {
    const query = productId ? `?productId=${encodeURIComponent(productId)}` : '';
    const res = await fetch(`${BASE_URL}/forecast${query}`);
    if (!res.ok) throw new Error('Failed to generate demand forecast');
    return res.json();
  },

  async analyzeForecastAI(productId = null) {
    const res = await fetch(`${BASE_URL}/forecast/ai-analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId })
    });
    if (!res.ok) throw new Error('Failed to run strategic forecast analysis');
    return res.json();
  },

  // Auth (Login & Signup)
  async login(email, password) {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Login failed. Check your credentials.');
    }
    return res.json();
  },

  async signup(data) {
    const res = await fetch(`${BASE_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || 'Signup failed.');
    }
    return res.json();
  },

  // Download full project ZIP
  async downloadZip() {
    const res = await fetch(`${BASE_URL}/download-zip`);
    if (!res.ok) throw new Error('Failed to generate project ZIP archive');
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'warehouse-system.zip';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  },

  // Dashboard Stats
  async getStats() {
    const res = await fetch(`${BASE_URL}/stats`);
    if (!res.ok) throw new Error('Failed to fetch warehouse statistics');
    return res.json();
  }
};
