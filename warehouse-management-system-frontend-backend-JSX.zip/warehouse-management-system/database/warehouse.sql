CREATE DATABASE IF NOT EXISTS warehouse_management;
USE warehouse_management;

CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(40) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(60) NOT NULL DEFAULT 'Inventory Specialist',
  avatar_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS suppliers (
  id VARCHAR(40) PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  code VARCHAR(40) NOT NULL UNIQUE,
  contact_person VARCHAR(120),
  email VARCHAR(190),
  phone VARCHAR(40),
  lead_time_days INT DEFAULT 0,
  rating DECIMAL(3,2) DEFAULT 0,
  status ENUM('ACTIVE','INACTIVE') DEFAULT 'ACTIVE'
);

CREATE TABLE IF NOT EXISTS warehouse_locations (
  id VARCHAR(40) PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  zone VARCHAR(120), aisle VARCHAR(60), rack VARCHAR(60), shelf VARCHAR(60),
  type VARCHAR(40), max_capacity INT DEFAULT 0, current_occupancy INT DEFAULT 0,
  status VARCHAR(40) DEFAULT 'AVAILABLE'
);

CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(40) PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  sku VARCHAR(100) NOT NULL UNIQUE,
  category VARCHAR(120),
  price DECIMAL(12,2) NOT NULL DEFAULT 0,
  quantity INT NOT NULL DEFAULT 0,
  unit VARCHAR(40),
  supplier_id VARCHAR(40),
  location_id VARCHAR(40),
  low_stock_threshold INT DEFAULT 0,
  description TEXT,
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_products_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
  CONSTRAINT fk_products_location FOREIGN KEY (location_id) REFERENCES warehouse_locations(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS stock_movements (
  id VARCHAR(40) PRIMARY KEY,
  product_id VARCHAR(40) NOT NULL,
  type VARCHAR(40) NOT NULL,
  quantity INT NOT NULL,
  from_location VARCHAR(40), to_location VARCHAR(40),
  reference_number VARCHAR(100), reason TEXT, operator VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_movements_product FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id VARCHAR(40) PRIMARY KEY,
  order_number VARCHAR(80) NOT NULL UNIQUE,
  supplier_id VARCHAR(40),
  status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  order_date DATE,
  expected_delivery_date DATE,
  received_date DATE,
  destination_location_id VARCHAR(40),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
  CONSTRAINT fk_orders_location FOREIGN KEY (destination_location_id) REFERENCES warehouse_locations(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  purchase_order_id VARCHAR(40) NOT NULL,
  product_id VARCHAR(40) NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_po_items_order FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_po_items_product FOREIGN KEY (product_id) REFERENCES products(id)
);
